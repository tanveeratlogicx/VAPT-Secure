#!/usr/bin/env php
<?php
/**
 * VAPTSchema Builder v3.0.0 - Package Creator
 * Creates distribution package without dependencies on ?? operator
 */

define('VERSION', '3.0.0');
define('PACK_DIR', dirname(__DIR__));
define('BUILD_DIR', PACK_DIR . '/build');
define('OUTPUT_DIR', PACK_DIR . '/dist');

echo "Creating VAPTSchema Builder package v" . VERSION . "\n";
echo str_repeat('-', 60) . "\n";

// Clean up
@rmdir(BUILD_DIR);
@rmdir(OUTPUT_DIR);

// Create directories
mkdir(BUILD_DIR, 0755, true);
mkdir(OUTPUT_DIR, 0755, true);

// Files to copy
$files = [
    'SKILL_enhanced.md' => 'SKILL.md',
    'DEVELOPER_GUIDE.md' => 'DEVELOPER_GUIDE.md',
    'WORDPRESS_REST_INTEGRATION_GUIDE.md' => 'WORDPRESS_REST_INTEGRATION_GUIDE.md'
];

echo "Copying core files...\n";
foreach ($files as $source => $target) {
    if (file_exists(PACK_DIR . '/' . $source)) {
        copy(PACK_DIR . '/' . $source, BUILD_DIR . '/' . $target);
        echo "  ✓ $source -> $target\n";
    }
}

// Copy resources
echo "\nCopying resources...\n";
$res_dir = BUILD_DIR . '/resources';
mkdir($res_dir, 0755, true);

$resource_files = glob(PACK_DIR . '/resources/*.json');
foreach ($resource_files as $file) {
    copy($file, $res_dir . '/' . basename($file));
    echo "  ✓ " . basename($file) . "\n";
}

// Copy scripts
echo "\nCopying scripts...\n";
$script_dir = BUILD_DIR . '/scripts';
mkdir($script_dir, 0755, true);

$script_files = glob(PACK_DIR . '/scripts/*.php');
foreach ($script_files as $file) {
    copy($file, $script_dir . '/' . basename($file));
    chmod($script_dir . '/' . basename($file), 0755);
    echo "  ✓ " . basename($file) . "\n";
}

// Copy examples
echo "\nCopying examples...\n";
$example_dir = BUILD_DIR . '/examples';
mkdir($example_dir, 0755, true);

$example_files = glob(PACK_DIR . '/examples/*.json');
foreach ($example_files as $file) {
    copy($file, $example_dir . '/' . basename($file));
    echo "  ✓ " . basename($file) . "\n";
}

// Create documentation
echo "\nCreating documentation...\n";
$docs_dir = BUILD_DIR . '/docs';
mkdir($docs_dir, 0755, true);

// Create simple README
$readme = "# VAPTSchema Builder v" . VERSION . "\n\n";
$readme .= "Complete WordPress REST API implementation generator for VAPT security controls.\n";
$readme .= "\n## Quick Start\n\n";
$readme .= "See WORDPRESS_REST_INTEGRATION_GUIDE.md for complete documentation.\n";

file_put_contents($docs_dir . '/README.md', $readme);
echo "  ✓ docs/README.md\n";

// Create LICENSE
$license = "MIT License\n\nCopyright (c) 2024 VAPTSchema Builder\n\n";
file_put_contents(BUILD_DIR . '/LICENSE', $license);
echo "  ✓ LICENSE\n";

// Create CHANGELOG
$changelog = "# Changelog\n\n## [" . VERSION . "] - 2024-01-19\n\n### Added\n";
$changelog .= "- WordPress REST API native integration\n";
$changelog .= "- PHP implementation code generation\n";
file_put_contents(BUILD_DIR . '/CHANGELOG.md', $changelog);
echo "  ✓ CHANGELOG.md\n";

// Create main README
$main_readme = "# VAPTSchema Builder v" . VERSION . "\n\n";
$main_readme .= "WordPress REST API compatible implementation generator.\n\n";
$main_readme .= "## Features\n\n";
$main_readme .= "- Full REST API integration\n";
$main_readme .= "- PHP code generation\n";
$main_readme .= "- Multi-platform support\n";
$main_readme .= "- Automated testing\n\n";
$main_readme .= "## Documentation\n\n";
$main_readme .= "- WORDPRESS_REST_INTEGRATION_GUIDE.md\n";
$main_readme .= "- DEVELOPER_GUIDE.md\n";

file_put_contents(BUILD_DIR . '/README.md', $main_readme);
echo "  ✓ README.md\n";

// Create zip
echo "\nCreating zip package...\n";
$zip_file = OUTPUT_DIR . '/VAPTSchema-Builder-v' . VERSION . '.zip';
$zip = new ZipArchive();

if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(BUILD_DIR),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    
    foreach ($files as $file) {
        if ($file->isFile()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen(BUILD_DIR) + 1);
            $zip->addFile($filePath, $relativePath);
        }
    }
    
    $zip->close();
    echo "  ✓ " . basename($zip_file) . "\n";
} else {
    echo "  ✗ Failed to create zip\n";
    exit(1);
}

// Generate checksum
echo "\nGenerating checksums...\n";
$sha256 = hash_file('sha256', $zip_file);
file_put_contents($zip_file . '.sha256', $sha256);
echo "  ✓ SHA256: " . $sha256 . "\n";

// Summary
$filesize = filesize($zip_file);
echo "\n" . str_repeat('-', 60) . "\n";
echo "✓ Package created successfully!\n";
echo "  File: " . $zip_file . "\n";
echo "  Size: " . round($filesize / 1024, 2) . " KB\n";
echo "  SHA256: " . $sha256 . "\n";
echo str_repeat('-', 60) . "\n";

echo "\nNext steps:\n";
echo "  1. Extract the package\n";
echo "  2. Read WORDPRESS_REST_INTEGRATION_GUIDE.md\n";
echo "  3. Start generating implementations\n";
echo "\n";
