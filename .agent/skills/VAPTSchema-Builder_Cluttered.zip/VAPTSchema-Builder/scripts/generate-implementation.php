#!/usr/bin/env php
<?php
/**
 * VAPT Implementation Generator v3.0.0
 * 
 * Generates WordPress REST API compatible implementations from VAPT Risk Catalogs
 * 
 * Usage: php generate-implementation.php RISK-ID [--output=/path] [--bundle]
 */

// Exit if direct access
if (php_sapi_name() !== 'cli') {
    exit(1);
}

// Constants
define('VAPT_VERSION', '3.0.0');
define('VAPT_DIR', dirname(__DIR__));
define('RESOURCES_DIR', VAPT_DIR . '/resources');
define('EXAMPLES_DIR', VAPT_DIR . '/examples');

// Required resource files
$REQUIRED_FILES = [
    'interface_schema_v2.0.json',
    'enforcer_pattern_library_v2.0.json',
    'rest_api_schema_template_v3.0.json',
    'php_code_templates_v3.0.json',
    'test_templates_v3.0.json'
];

// Parse command line arguments
$arguments = getopt('', ['risk-id:', 'output:', 'bundle', 'help', 'list-risks']);

// Show help
if (isset($arguments['help'])) {
    show_help();
    exit(0);
}

// List available risks
if (isset($arguments['list-risks'])) {
    list_risks();
    exit(0);
}

// Get risk ID
$risk_id = isset($arguments['risk-id']) 
    ? strtoupper($arguments['risk-id']) 
    : readline("Enter Risk ID (e.g., RISK-002): ");

if (empty($risk_id) || !preg_match('/^RISK-\d{3}$/', $risk_id)) {
    echo "Error: Invalid Risk ID format. Expected format: RISK-NNN\n";
    exit(1);
}

// Output directory
$output_dir = isset($arguments['output']) 
    ? $arguments['output'] 
    : VAPT_DIR . "/generated/{$risk_id}";

// Create output directory
if (!is_dir($output_dir)) {
    mkdir($output_dir, 0755, true);
}

// Generate implementation
echo "Generating implementation for {$risk_id}...\n";
echo "Output directory: {$output_dir}\n";
echo str_repeat('-', 60) . "\n";

try {
    // Load resources
    echo "Loading resource files...\n";
    $resources = load_resources();
    
    // Get risk data
    echo "Extracting risk data...\n";
    $risk_data = extract_risk_data($risk_id, $resources);
    
    // Generate schema.json
    echo "Generating schema.json...\n";
    $schema = generate_schema($risk_id, $risk_data, $resources);
    file_put_contents("{$output_dir}/schema.json", json_encode($schema, JSON_PRETTY_PRINT));
    echo "  ✓ schema.json\n";
    
    // Generate implementation.php
    echo "Generating implementation.php...\n";
    $implementation = generate_implementation($risk_id, $risk_data, $resources);
    file_put_contents("{$output_dir}/implementation.php", $implementation);
    echo "  ✓ implementation.php\n";
    
    // Generate rest_schema.json
    echo "Generating rest_schema.json...\n";
    $rest_schema = generate_rest_schema($risk_id, $risk_data, $resources);
    file_put_contents("{$output_dir}/rest_schema.json", json_encode($rest_schema, JSON_PRETTY_PRINT));
    echo "  ✓ rest_schema.json\n";
    
    // Generate test_suite.php
    echo "Generating test_suite.php...\n";
    $test_suite = generate_test_suite($risk_id, $risk_data, $resources);
    file_put_contents("{$output_dir}/test_suite.php", $test_suite);
    echo "  ✓ test_suite.php\n";
    
    // Generate integration-test.sh
    echo "Generating integration-test.sh...\n";
    $integration_test = generate_integration_test($risk_id, $risk_data, $resources);
    file_put_contents("{$output_dir}/integration-test.sh", $integration_test);
    chmod("{$output_dir}/integration-test.sh", 0755);
    echo "  ✓ integration-test.sh\n";
    
    // Generate documentation.md
    echo "Generating documentation.md...\n";
    $documentation = generate_documentation($risk_id, $risk_data);
    file_put_contents("{$output_dir}/documentation.md", $documentation);
    echo "  ✓ documentation.md\n";
    
    // Generate integration.yaml
    echo "Generating integration.yaml...\n";
    $integration_yaml = generate_integration_yaml($risk_id, $risk_data);
    file_put_contents("{$output_dir}/integration.yaml", $integration_yaml);
    echo "  ✓ integration.yaml\n";
    
    echo str_repeat('-', 60) . "\n";
    echo "✓ Implementation generated successfully!\n";
    echo "📁 Location: {$output_dir}\n";
    
    // Validate output if requested
    if (isset($arguments['bundle'])) {
        echo "\nBundling output...\n";
        create_bundle($output_dir, $risk_id);
        echo "✓ Bundle created: {$output_dir}.zip\n";
    }
    
} catch (Exception $e) {
    echo "\n✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}

/**
 * Load all required resource files
 */
function load_resources() {
    $resources = [];
    
    foreach ($REQUIRED_FILES as $file) {
        $path = RESOURCES_DIR . '/' . $file;
        if (!file_exists($path)) {
            throw new Exception("Required resource file not found: {$file}");
        }
        $content = file_get_contents($path);
        $resources[$file] = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON in {$file}: " . json_last_error_msg());
        }
    }
    
    return $resources;
}

/**
 * Extract risk data from resources
 */
function extract_risk_data($risk_id, $resources) {
    // Get interface schema data
    $interface_schema = $resources['interface_schema_v2.0.json'];
    if (!isset($interface_schema['risk_interfaces'][$risk_id])) {
        throw new Exception("Risk ID {$risk_id} not found in interface schema");
    }
    
    // Get pattern library data
    $pattern_library = $resources['enforcer_pattern_library_v2.0.json'];
    if (!isset($pattern_library['patterns'][$risk_id])) {
        throw new Exception("Risk ID {$risk_id} not found in pattern library");
    }
    
    return [
        'interface' => $interface_schema['risk_interfaces'][$risk_id],
        'pattern' => $pattern_library['patterns'][$risk_id],
        'rest_template' => $resources['rest_api_schema_template_v3.0.json'],
        'php_template' => $resources['php_code_templates_v3.0.json'],
        'test_template' => $resources['test_templates_v3.0.json']
    ];
}

/**
 * Generate schema.json
 */
function generate_schema($risk_id, $risk_data, $resources) {
    $interface = $risk_data['interface'];
    $pattern = $risk_data['pattern'];
    
    // Extract driver from pattern
    $driver_types = array_keys($pattern);
    $driver = $driver_types[0]; // Use first available driver
    
    $pattern_data = $pattern[$driver];
    
    // Build schema
    $schema = [
        'risk_id' => $risk_id,
        'title' => $interface['title'] ?? '',
        'category' => $interface['category'] ?? '',
        'severity' => $interface['severity']['level'] ?? 'medium',
        'version' => VAPT_VERSION,
        
        'ui_configuration' => [
            'controls' => $interface['ui_configuration']['components'] ?? []
        ],
        
        'enforcement' => [
            'driver' => $driver,
            'mappings' => [],
            'insertion_point' => $pattern_data['insertion_point'] ?? null,
            'target_file' => $pattern_data['target_file'] ?? null,
            'idempotency' => [
                'check_string' => $pattern_data['begin_marker'] ?? null,
                'if_found' => 'skip'
            ],
            'verification' => [
                'command' => $pattern_data['verification']['command'] ?? '',
                'expected' => $pattern_data['verification']['expected'] ?? ''
            ]
        ],
        
        'rest_api' => [
            'namespace' => 'vapt/v1',
            'route' => '/risk-' . str_replace('RISK-', '', $risk_id),
            'methods' => ['GET', 'POST', 'DELETE']
        ],
        
        'php_implementation' => [
            'rest_handler' => 'vapt_rest_handle_' . strtolower($risk_id),
            'enforcement_handler' => 'vapt_enforce_' . strtolower($risk_id),
            'validation_handler' => 'vapt_validate_' . strtolower($risk_id) . '_settings'
        ]
    ];
    
    // Add control mappings
    if (isset($interface['ui_configuration']['components'])) {
        foreach ($interface['ui_configuration']['components'] as $component) {
            $schema['enforcement']['mappings'][$component['component_id']] = 
                $pattern_data['code'] ?? $pattern_data['raw_code'] ?? '';
        }
    }
    
    return $schema;
}

/**
 * Generate implementation.php
 */
function generate_implementation($risk_id, $risk_data, $resources) {
    $interface = $risk_data['interface'];
    $pattern = $risk_data['pattern'];
    $templates = $resources['php_code_templates_v3.0.json'];
    
    // Extract driver
    $driver_types = array_keys($pattern);
    $driver = $driver_types[0];
    $pattern_data = $pattern[$driver];
    
    // Prepare template bindings
    $risk_number = str_replace(['RISK-', 'RISK_'], '', $risk_id);
    $risk_id_clean = str_replace('-', '_', $risk_id);
    
    // Build component info
    $components = $interface['ui_configuration']['components'] ?? [];
    $first_component = $components[0] ?? null;
    $component_id = $first_component['component_id'] ?? '';
    
    $bindings = [
        'RISK_ID' => $risk_id,
        'RISK_ID_CLEAN' => $risk_id_clean,
        'RISK_TITLE' => $interface['title'] ?? '',
        'VERSION' => VAPT_VERSION,
        'risk_nnn' => $risk_number,
        'component_id' => $component_id,
        'enforcement_driver' => $driver,
        'target_path' => str_replace('{ABSPATH}', '', $pattern_data['target_file'] ?? ''),
        'file_relative_path' => $pattern_data['target_file'] ?? '',
        'control_key' => $component_id
    ];
    
    // Build PHP code from templates
    $php_code = "<?php\n";
    $php_code .= "/**\n * VAPT Risk {$risk_id} Implementation\n";
    $php_code .= " * {$interface['title']}\n";
    $php_code .= " * \n * Auto-generated by VAPTSchema Builder v" . VAPT_VERSION . "\n";
    $php_code .= " * DO NOT EDIT MANUALLY - Regenerate via skill\n * \n * @package VAPT_Protection_Suite\n */\n\n";
    $php_code .= "if (!defined('ABSPATH')) {\n    exit;\n}\n\n";
    
    // Add REST registration
    $php_code .= "// REST API Registration\n";
    $php_code .= "add_action('rest_api_init', 'vapt_register_rest_routes_{$risk_number}');\n\n";
    $php_code .= "function vapt_register_rest_routes_{$risk_number}() {\n";
    $php_code .= "    register_rest_route('vapt/v1', '/risk-{$risk_number}', [\n";
    $php_code .= "        'methods' => ['GET', 'POST', 'DELETE'],\n";
    $php_code .= "        'callback' => 'vapt_rest_handle_{$risk_number}',\n";
    $php_code .= "        'permission_callback' => function() {\n";
    $php_code .= "            return current_user_can('manage_options');\n";
    $php_code .= "        },\n";
    $php_code .= "        'args' => [\n";
    $php_code .= "            '{$component_id}' => [\n";
    $php_code .= "                'type' => 'boolean',\n";
    $php_code .= "                'description' => '{$interface['title']}',\n";
    $php_code .= "                'default' => true,\n";
    $php_code .= "                'sanitize_callback' => 'rest_sanitize_boolean'\n";
    $php_code .= "            ]\n";
    $php_code .= "        ]\n";
    $php_code .= "    ]);\n}\n\n";
    
    // Add REST handler
    $php_code .= "/**\n * REST Handler\n */\n";
    $php_code .= "function vapt_rest_handle_{$risk_number}(\$request) {\n";
    $php_code .= "    \$method = \$request->get_method();\n";
    $php_code .= "    \n";
    $php_code .= "    switch (\$method) {\n";
    $php_code .= "        case 'GET':\n";
    $php_code .= "            return vapt_rest_get_{$risk_number}(\$request);\n";
    $php_code .= "        case 'POST':\n";
    $php_code .= "            return vapt_rest_update_{$risk_number}(\$request);\n";
    $php_code .= "        case 'DELETE':\n";
    $php_code .= "            return vapt_rest_delete_{$risk_number}(\$request);\n";
    $php_code .= "        default:\n";
    $php_code .= "            return new WP_Error('invalid_method', 'Method not allowed', ['status' => 405]);\n";
    $php_code .= "    }\n}\n\n";
    
    // Add GET handler
    $php_code .= "/**\n * GET Handler\n */\n";
    $php_code .= "function vapt_rest_get_{$risk_number}(\$request) {\n";
    $php_code .= "    \$settings = get_option('vapt_{$risk_number}_settings', []);\n";
    $php_code .= "    \$status = vapt_check_enforcement_{$risk_number}();\n";
    $php_code .= "    \n";
    $php_code .= "    return [\n";
    $php_code .= "        '{$component_id}' => \$settings['{$component_id}'] ?? true,\n";
    $php_code .= "        'status' => \$status['status'],\n";
    $php_code .= "        'last_verified' => \$settings['last_verified'] ?? null,\n";
    $php_code .= "        'enforcement_details' => [\n";
    $php_code .= "            'driver' => '{$driver}',\n";
    $php_code .= "            'target_file' => ABSPATH . '" . (isset($pattern_data['target_file']) ? $pattern_data['target_file'] : '') . "',\n";
    $php_code .= "            'insertion_point' => '" . (isset($pattern_data['insertion_point']) ? $pattern_data['insertion_point'] : '') . "'\n";
    $php_code .= "        ]\n";
    $php_code .= "    ];\n}\n\n";
    
    // Add POST handler
    $php_code .= "/**\n * POST Handler\n */\n";
    $php_code .= "function vapt_rest_update_{$risk_number}(\$request) {\n";
    $php_code .= "    \$params = \$request->get_json_params();\n";
    $php_code .= "    \$enabled = isset(\$params['{$component_id}']) \n";
    $php_code .= "        ? rest_sanitize_boolean(\$params['{$component_id}'])\n";
    $php_code .= "        : true;\n";
    $php_code .= "    \n";
    $php_code .= "    // Save settings\n";
    $php_code .= "    \$settings = get_option('vapt_{$risk_number}_settings', []);\n";
    $php_code .= "    \$settings['{$component_id}'] = \$enabled;\n";
    $php_code .= "    \$settings['updated_at'] = current_time('mysql');\n";
    $php_code .= "    update_option('vapt_{$risk_number}_settings', \$settings);\n";
    $php_code .= "    \n";
    $php_code .= "    // Apply enforcement\n";
    $php_code .= "    \$result = vapt_enforce_{$risk_number}(\$enabled);\n";
    $php_code .= "    \n";
    $php_code .= "    if (is_wp_error(\$result)) {\n";
    $php_code .= "        return \$result;\n";
    $php_code .= "    }\n";
    $php_code .= "    \n";
    $php_code .= "    // Verify\n";
    $php_code .= "    \$check = vapt_check_enforcement_{$risk_number}();\n";
    $php_code .= "    \$settings['last_verified'] = current_time('mysql');\n";
    $php_code .= "    \$settings['status'] = \$check['status'];\n";
    $php_code .= "    update_option('vapt_{$risk_number}_settings', \$settings);\n";
    $php_code .= "    \n";
    $php_code .= "    return [\n";
    $php_code .= "        'success' => true,\n";
    $php_code .= "        '{$component_id}' => \$enabled,\n";
    $php_code .= "        'status' => \$check['status']\n";
    $php_code .= "    ];\n";
    $php_code .= "}\n\n";
    
    // Add DELETE handler
    $php_code .= "/**\n * DELETE Handler\n */\n";
    $php_code .= "function vapt_rest_delete_{$risk_number}(\$request) {\n";
    $php_code .= "    \$result = vapt_remove_enforcement_{$risk_number}();\n";
    $php_code .= "    \n";
    $php_code .= "    if (is_wp_error(\$result)) {\n";
    $php_code .= "        return \$result;\n";
    $php_code .= "    }\n";
    $php_code .= "    \n";
    $php_code .= "    delete_option('vapt_{$risk_number}_settings');\n";
    $php_code .= "    \n";
    $php_code .= "    return [\n";
    $php_code .= "        'success' => true,\n";
    $php_code .= "        'message' => 'Protection removed'\n";
    $php_code .= "    ];\n";
    $php_code .= "}\n\n";
    
    // Add enforcement handler based on driver type
    $php_code .= build_enforcement_function($risk_number, $driver, $pattern_data);
    
    return $php_code;
}

/**
 * Build enforcement function based on driver
 */
function build_enforcement_function($risk_number, $driver, $pattern_data) {
    $code = "/**\n * Apply Enforcement\n */\n";
    $code .= "function vapt_enforce_{$risk_number}(\$enabled) {\n";
    
    if ($driver === 'htaccess' || $driver === 'htaccess-uploads') {
        $target_file = str_replace('{ABSPATH}', 'ABSPATH . \'\'', $pattern_data['target_file']);
        $target_file = str_replace('{ABSPATH', '\'ABSPATH', $target_file);
        
        $code .= "    \$target_file = {$target_file};\n";
        $code .= "    \n";
        $code .= "    if (!file_exists(\$target_file)) {\n";
        $code .= "        touch(\$target_file);\n";
        $code .= "    }\n";
        $code .= "    \n";
        $code .= "    if (!is_writable(\$target_file)) {\n";
        $code .= "        return new WP_Error('file_not_writable', 'Cannot write file', 500);\n";
        $code .= "    }\n";
        $code .= "    \n";
        $code .= "    \$content = file_get_contents(\$target_file);\n";
        $code .= "    \$marker = 'VAPT RISK-' . str_replace('RISK-', '', \$risk_number);\n";
        $code .= "    \$content = preg_replace('/# BEGIN \\$marker.*?# END \\$marker\\s*/s', '', \$content);\n";
        $code .= "    \n";
        $code .= "    if (\$enabled) {\n";
        $code .= "        \$block = \"# BEGIN VAPT RISK-\" . str_replace('RISK-', '', \$risk_number) . \"\\n\" . \n";
        $code .= "                 \"" . addslashes($pattern_data['raw_code']) . "\\n\" . \n";
        $code .= "                 \"# END VAPT RISK-\" . str_replace('RISK-', '', \$risk_number);\n";
        $code .= "        \$content = \$block . \"\\n\" . \$content;\n";
        $code .= "    }\n";
        $code .= "    \n";
        $code .= "    copy(\$target_file, \$target_file . '.vapt.bak.' . time());\n";
        $code .= "    file_put_contents(\$target_file, \$content);\n";
        $code .= "    \n";
        $code .= "    return true;\n";
        $code .= "}\n\n";
    } elseif ($driver === 'wp_config') {
        $code .= "    // wp-config enforcement\n";
        $code .= "    \$target_file = ABSPATH . 'wp-config.php';\n";
        $code .= "    // Similar logic to htaccess...\n";
        $code .= "    return true;\n";
        $code .= "}\n\n";
    } else {
        $code .= "    // Generic enforcement hook-based\n";
        $code .= "    // Add your enforcement logic here\n";
        $code .= "    return true;\n";
        $code .= "}\n\n";
    }
    
    // Add check enforcement
    $code .= "/**\n * Check Enforcement\n */\n";
    $code .= "function vapt_check_enforcement_{$risk_number}() {\n";
    $code .= "    \$target_file = ABSPATH . '" . str_replace('{ABSPATH}', '', $pattern_data['target_file'] ?? '') . "';\n";
    $code .= "    \n";
    $code .= "    if (!file_exists(\$target_file)) {\n";
    $code .= "        return ['status' => 'not_applied'];\n";
    $code .= "    }\n";
    $code .= "    \n";
    $code .= "    \$content = file_get_contents(\$target_file);\n";
    $code .= "    \$marker = '# BEGIN VAPT RISK-' . str_replace('RISK-', '', \$risk_number);\n";
    $code .= "    \n";
    $code .= "    if (strpos(\$content, \$marker) === false) {\n";
    $code .= "        return ['status' => 'not_applied'];\n";
    $code .= "    }\n";
    $code .= "    \n";
    $code .= "    return ['status' => 'applied'];\n";
    $code .= "}\n\n";
    
    // Add remove enforcement
    $code .= "/**\n * Remove Enforcement\n */\n";
    $code .= "function vapt_remove_enforcement_{$risk_number}() {\n";
    $code .= "    \$target_file = ABSPATH . '" . str_replace('{ABSPATH}', '', $pattern_data['target_file'] ?? '') . "';\n";
    $code .= "    \n";
    $code .= "    if (!file_exists(\$target_file)) {\n";
    $code .= "        return true;\n";
    $code .= "    }\n";
    $code .= "    \n";
    $code .= "    \$content = file_get_contents(\$target_file);\n";
    $code .= "    \$marker = 'VAPT RISK-' . str_replace('RISK-', '', \$risk_number);\n";
    $code .= "    \$new_content = preg_replace('/# BEGIN \\$marker.*?# END \\$marker\\s*/s', '', \$content);\n";
    $code .= "    \n";
    $code .= "    file_put_contents(\$target_file, \$new_content);\n";
    $code .= "    \n";
    $code .= "    return true;\n";
    $code .= "}\n\n";
    
    return $code;
}

/**
 * Generate rest_schema.json
 */
function generate_rest_schema($risk_id, $risk_data, $resources) {
    $template = $resources['rest_api_schema_template_v3.0.json'];
    $interface = $risk_data['interface'];
    
    $risk_number = str_replace('RISK-', '', $risk_id);
    $components = $interface['ui_configuration']['components'] ?? [];
    
    $schema = $template['template']['rest_api'];
    $schema['route'] = '/risk-' . $risk_number;
    $schema['endpoint_schema']['title'] = "VAPT Risk {$risk_id} - {$interface['title']}";
    
    return $schema;
}

/**
 * Generate test_suite.php
 */
function generate_test_suite($risk_id, $risk_data, $resources) {
    $template = $resources['test_templates_v3.0.json']['templates']['phpunit_test'];
    $interface = $risk_data['interface'];
    $pattern = $risk_data['pattern'];
    
    $driver_types = array_keys($pattern);
    $driver = $driver_types[0];
    $pattern_data = $pattern[$driver];
    
    $risk_number = str_replace('RISK-', '', $risk_id);
    $risk_id_clean = str_replace('-', '_', $risk_id);
    $components = $interface['ui_configuration']['components'] ?? [];
    $component_id = $components[0]['component_id'] ?? '';
    
    $bindings = [
        'RISK_ID' => $risk_id,
        'RISK_ID_CLEAN' => $risk_id_clean,
        'RISK_TITLE' => $interface['title'] ?? '',
        'risk_nnn' => $risk_number,
        'component_id' => $component_id,
        'enforcement_driver' => $driver,
        'target_path' => str_replace('{ABSPATH}', '', $pattern_data['target_file'] ?? ''),
        'file_relative_path' => $pattern_data['target_file'] ?? '',
        'control_key' => $component_id
    ];
    
    $test_code = apply_template($template, $bindings);
    
    return $test_code;
}

/**
 * Generate integration-test.sh
 */
function generate_integration_test($risk_id, $risk_data, $resources) {
    $template = $resources['test_templates_v3.0.json']['templates']['integration_test'];
    
    // Template replacement would happen here
    // For now, return simplified version
    return "#!/bin/bash\n# Integration tests for {$risk_id}\n\nset -e\n\necho \"Integration tests for {$risk_id}\"\necho \"TODO: Implement specific tests\"\n";
}

/**
 * Generate documentation.md
 */
function generate_documentation($risk_id, $risk_data) {
    $interface = $risk_data['interface'];
    
    $doc = "# {$risk_id} Implementation Documentation\n\n";
    $doc .= "## {$interface['title']}\n\n";
    $doc .= "**Category:** {$interface['category']}\n\n";
    $doc .= "**Severity:** {$interface['severity']['level']}\n\n";
    $doc .= "---\n\n";
    $doc .= "## REST API Endpoints\n\n";
    $doc .= "### GET /wp-json/vapt/v1/risk-" . str_replace('RISK-', '', $risk_id) . "\n";
    $doc .= "Retrieves current protection status.\n\n";
    $doc .= "### POST /wp-json/vapt/v1/risk-" . str_replace('RISK-', '', $risk_id) . "\n";
    $doc .= "Enable or disable protection.\n\n";
    $doc .= "### DELETE /wp-json/vapt/v1/risk-" . str_replace('RISK-', '', $risk_id) . "\n";
    $doc .= "Remove protection enforcement.\n\n";
    
    return $doc;
}

/**
 * Generate integration.yaml
 */
function generate_integration_yaml($risk_id, $risk_data) {
    $risk_number = str_replace('RISK-', '', $risk_id);
    
    return "# CI/CD Integration for {$risk_id}\n\n";
}

/**
 * Create zip bundle
 */
function create_bundle($source_dir, $name) {
    $zip = new ZipArchive();
    $zip_file = $source_dir . '.zip';
    
    if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source_dir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($source_dir) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        
        $zip->close();
    }
}

/**
 * Apply template bindings
 */
function apply_template($template, $bindings) {
    $result = $template;
    
    foreach ($bindings as $key => $value) {
        $result = str_replace('{' . $key . '}', $value, $result);
    }
    
    return $result;
}

/**
 * Show help
 */
function show_help() {
    echo "VAPT Implementation Generator v" . VAPT_VERSION . "\n\n";
    echo "Usage: php generate-implementation.php [options]\n\n";
    echo "Options:\n";
    echo "  --risk-id=ID         Risk ID to generate (e.g., RISK-002)\n";
    echo "  --output=PATH        Output directory (default: generated/RISK-ID)\n";
    echo "  --bundle             Create zip bundle of output\n";
    echo "  --list-risks         List all available risk IDs\n";
    echo "  --help               Show this help message\n\n";
    echo "Examples:\n";
    echo "  php generate-implementation.php --risk-id=RISK-002\n";
    echo "  php generate-implementation.php --risk-id=RISK-020 --bundle\n";
    echo "  php generate-implementation.php --list-risks\n\n";
}

/**
 * List available risks
 */
function list_risks() {
    $path = RESOURCES_DIR . '/interface_schema_v2.0.json';
    $data = json_decode(file_get_contents($path), true);
    
    echo "Available Risk IDs:\n";
    echo str_repeat('-', 60) . "\n";
    
    foreach ($data['risk_interfaces'] as $risk_id => $info) {
        echo sprintf("%-12s %-50s\n", $risk_id, $info['title']);
    }
}
