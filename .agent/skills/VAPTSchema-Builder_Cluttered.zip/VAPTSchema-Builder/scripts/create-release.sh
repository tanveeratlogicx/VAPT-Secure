#!/bin/bash
#
# VAPTSchema Builder v3.0.0 Release Package Creator
#
# Creates a distribution zip with all skill enhancements
#

set -e

# Configuration
VERSION="3.0.0"
PACKAGE_NAME="VAPTSchema-Builder-v${VERSION}"
BUILD_DIR="$(pwd)/build"
OUTPUT_DIR="$(pwd)/dist"

echo "========================================="
echo "VAPTSchema Builder Release Package v${VERSION}"
echo "========================================="
echo ""

# Clean build directory
echo "Cleaning build directory..."
rm -rf "${BUILD_DIR}"
rm -rf "${OUTPUT_DIR}"
mkdir -p "${BUILD_DIR}"
mkdir -p "${OUTPUT_DIR}"

# Copy core skill files
echo "Copying core skill files..."
cp SKILL_enhanced.md "${BUILD_DIR}/SKILL.md"
cp DEVELOPER_GUIDE.md "${BUILD_DIR}/"
cp WORDPRESS_REST_INTEGRATION_GUIDE.md "${BUILD_DIR}/"

# Create resources directory
echo "Copying resources..."
mkdir -p "${BUILD_DIR}/resources"
cp resources/*.json "${BUILD_DIR}/resources/" 2>/dev/null || true
cp -r resources/*.md "${BUILD_DIR}/resources/" 2>/dev/null || true

# Create scripts directory
echo "Copying scripts..."
mkdir -p "${BUILD_DIR}/scripts"
cp scripts/*.php "${BUILD_DIR}/scripts/" 2>/dev/null || true
cp scripts/*.sh "${BUILD_DIR}/scripts/" 2>/dev/null || true
chmod +x "${BUILD_DIR}/scripts"/*.sh "${BUILD_DIR}/scripts"/*.php 2>/dev/null || true

# Create examples directory
echo "Creating examples..."
mkdir -p "${BUILD_DIR}/examples"

# Generate example implementation for RISK-002
echo "Generating example implementation for RISK-002..."
php scripts/generate-implementation.php --risk-id=RISK-002 --output="${BUILD_DIR}/examples/risk-RISK-002" --bundle

# Generate example implementation for RISK-003
echo "Generating example implementation for RISK-003..."
php scripts/generate-implementation.php --risk-id=RISK-003 --output="${BUILD_DIR}/examples/risk-RISK-003" --bundle

# Generate example implementation for RISK-020
echo "Generating example implementation for RISK-020..."
php scripts/generate-implementation.php --risk-id=RISK-020 --output="${BUILD_DIR}/examples/risk-RISK-020" --bundle

# Copy original examples
cp examples/*.json "${BUILD_DIR}/examples/" 2>/dev/null || true

# Create documentation
echo "Creating documentation..."
mkdir -p "${BUILD_DIR}/docs"

cat > "${BUILD_DIR}/docs/README.md" << 'EOF'
# VAPTSchema Builder v3.0.0 Documentation

## Quick Start

1. **Generate an Implementation**
   
   ```bash
   php scripts/generate-implementation.php --risk-id=RISK-002 --bundle
   ```

2. **Install the Generated PHP Code**
   
   ```bash
   cp generated/RISK-002/implementation.php \
      wp-content/plugins/vapt-protection-suite/handlers/
   ```

3. **Use the REST API**
   
   ```bash
   # Get status
   curl https://example.com/wp-json/vapt/v1/risk-002
   
   # Enable protection
   curl -X POST \
     -H "Content-Type: application/json" \
     -d '{"UI-RISK-002-001": true}' \
     https://example.com/wp-json/vapt/v1/risk-002
   ```

## File Structure

```
VAPTSchema-Builder/
├── SKILL.md                                    # Main skill definition
├── DEVELOPER_GUIDE.md                          # Development guide
├── WORDPRESS_REST_INTEGRATION_GUIDE.md        # REST API integration
├── resources/                                  # Resource files
│   ├── interface_schema_v2.0.json             # UI component definitions
│   ├── enforcer_pattern_library_v2.0.json     # Enforcement patterns
│   ├── rest_api_schema_template_v3.0.json     # REST schema templates
│   ├── php_code_templates_v3.0.json           # PHP code templates
│   ├── test_templates_v3.0.json               # Test templates
│   └── vapt_driver_manifest_v2.0.json         # Driver configurations
├── scripts/                                    # Utility scripts
│   ├── generate-implementation.php            # Generator script
│   └── validate-schema.sh                     # Schema validator
├── examples/                                   # Example implementations
│   ├── risk-RISK-002.zip                      # xmlrpc protection
│   ├── risk-RISK-003.zip                      # REST API user enum protection
│   ├── risk-RISK-020.zip                      # PHP execution in uploads
│   └── example-*.json                         # JSON examples
└── docs/                                       # Additional documentation
```

## Resources

### Resource Files in Detail

| File | Purpose |
|------|---------|
| `interface_schema_v2.0.json` | UI component definitions for all 125 risks |
| `enforcer_pattern_library_v2.0.json` | Enforcement code patterns for all enforcer types |
| `rest_api_schema_template_v3.0.json` | WordPress REST API schema templates |
| `php_code_templates_v3.0.json` | PHP implementation code templates |
| `test_templates_v3.0.json` | PHPUnit and integration test templates |
| `vapt_driver_manifest_v2.0.json` | Driver execution configurations |

## Generating Implementations

### Command Line

```bash
# Generate with defaults
php scripts/generate-implementation.php --risk-id=RISK-002

# Generate with custom output
php scripts/generate-implementation.php \
  --risk-id=RISK-002 \
  --output=/custom/path \
  --bundle

# List all available risks
php scripts/generate-implementation.php --list-risks
```

### Output Bundle

Each generated bundle contains:

```
risk-RISK-002/
├── schema.json              # Interface schema
├── implementation.php       # Full PHP implementation
├── rest_schema.json         # REST API schema
├── test_suite.php           # PHPUnit tests
├── integration-test.sh      # Integration tests
├── documentation.md         # Risk-specific docs
└── integration.yaml         # CI/CD integration
```

## REST API Endpoints

### Standard Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/wp-json/vapt/v1/risk-{nnn}` | Get protection status |
| POST | `/wp-json/vapt/v1/risk-{nnn}` | Update protection |
| DELETE | `/wp-json/vapt/v1/risk-{nnn}` | Remove protection |
| GET | `/wp-json/vapt/v1/risk-{nnn}/verify` | Run verification |
| POST | `/wp-json/vapt/v1/risk-{nnn}/test` | Test protection |

### Example Usage

```javascript
// Get status
const response = await fetch('/wp-json/vapt/v1/risk-002');
const data = await response.json();

// Enable protection
const response = await fetch('/wp-json/vapt/v1/risk-002', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-WP-Nonce': wpApiSettings.nonce
  },
  body: JSON.stringify({
    'UI-RISK-002-001': true
  })
});
```

## Testing

### PHPUnit

```bash
cd wp-content/plugins/vapt-protection-suite
./vendor/bin/phpunit --testsuite=vapt risk-RISK-002/test_suite.php
```

### Integration Tests

```bash
cd risk-RISK-002
chmod +x integration-test.sh
./integration-test.sh
```

## Error Handling

All REST endpoints return standardized error responses:

```json
{
  "code": "error_code",
  "message": "Human readable message",
  "data": {
    "status": 400
  }
}
```

## Security

- All endpoints require `manage_options` capability
- Nonce verification for AJAX requests
- Input sanitization via WordPress REST API
- File permission checks before modifications
- Automatic backup creation before changes

## Support

For detailed guides, see:
- `WORDPRESS_REST_INTEGRATION_GUIDE.md` - REST API integration
- `DEVELOPER_GUIDE.md` - Development workflow
- `SKILL.md` - Skill usage and capabilities
EOF

# Create CHANGELOG
cat > "${BUILD_DIR}/CHANGELOG.md" << 'EOF'
# Changelog

## [3.0.0] - 2024-01-19

### Added
- WordPress REST API native integration
- Automatic PHP implementation code generation
- Production-ready REST endpoint handlers
- Automated test suite generation (PHPUnit + Bash)
- Security permission checks
- Nonce-based CSRF protection
- Input validation and sanitization
- File backup before modifications
- Idempotency checking to prevent duplicates
- Rollback capabilities
- Comprehensive error handling
- 24-point accuracy validation rubric
- CI/CD integration YAML templates
- Complete documentation suite

### Changed
- Enhanced skill definition with 24-point validation
- Improved driver support for all platforms
- Better error messages and debugging info
- Expanded security considerations

### Fixed
- .htaccess rewrite rule "dead zone" issue
- File permission handling
- Concurrent request safety
- JSON Schema validation

## [2.0.0] - Previous Release

### Added
- UI control generation
- Enforcement pattern library
- Multi-platform driver support
- Verification testing

EOF

# Create LICENSE
cat > "${BUILD_DIR}/LICENSE" << 'EOF'
MIT License

Copyright (c) 2024 VAPTSchema Builder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF

# Create README
cat > "${BUILD_DIR}/README.md" << 'EOF'
# VAPTSchema Builder v3.0.0

## Overview

VAPTSchema Builder is an expert skill for transforming VAPT Risk Catalogs into fully WordPress REST API compatible security implementations with automated PHP code generation.

**Version:** 3.0.0  
**Target:** WordPress 5.6+ with REST API  
**PHP:** 7.4+ or 8.0+

## Features

✅ **WordPress REST API Native** - Full REST endpoint generation with authentication  
✅ **PHP Code Generation** - Production-ready implementation code  
✅ **Multi-Platform Support** - Apache, Nginx, IIS, Caddy, Cloudflare  
✅ **Automated Testing** - PHPUnit integration tests + Bash test suites  
✅ **Security First** - Permission checks, nonce validation, input sanitization  
✅ **Rollback Safe** - Automatic backups and rollback capabilities  
✅ **>90% Accuracy** - 24-point validation rubric ensures quality  

## Quick Start

### 1. Generate an Implementation

```bash
php scripts/generate-implementation.php --risk-id=RISK-002 --bundle
```

### 2. Install in WordPress

```bash
# Copy to plugin
cd wp-content/plugins/vapt-protection-suite/handlers/
unzip /path/to/risk-RISK-002.zip

# Or manually
cp /path/to/risk-RISK-002/implementation.php class-vapt-risk-002.php
```

### 3. Use via REST API

```bash
# Check status
curl https://example.com/wp-json/vapt/v1/risk-002

# Enable protection
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"UI-RISK-002-001": true}' \
  https://example.com/wp-json/vapt/v1/risk-002
```

## Documentation

- **[Skill Definition](SKILL.md)** - Complete skill documentation
- **[Integration Guide](WORDPRESS_REST_INTEGRATION_GUIDE.md)** - REST API integration
- **[Developer Guide](DEVELOPER_GUIDE.md)** - Development workflow
- **[Documentation](docs/README.md)** - Detailed documentation

## Supported Risks

125 risks fully supported including:

- RISK-001: wp-cron.php DoS protection
- RISK-002: xmlrpc.php blocking
- RISK-003: REST API user enumeration
- RISK-020: PHP execution in uploads
- ...and 121 more

**List all risks:**
```bash
php scripts/generate-implementation.php --list-risks
```

## Requirements

### System Requirements

- WordPress 5.6 or higher
- PHP 7.4 or PHP 8.0+
- Apache 2.4+ or Nginx
- File system write permissions

### WordPress Requirements

- `manage_options` capability
- REST API enabled
- Ability to modify .htaccess or server config

## Installation

### Direct Install

```bash
cd wp-content/plugins/vapt-protection-suite
mkdir handlers

# Copy generated implementation
cp /path/to/risk-{ID}/implementation.php handlers/
```

### Bulk Install

```bash
./scripts/install-all-risks.sh
```

## Usage Examples

### JavaScript (React)
```javascript
import { apiFetch } from '@wordpress/api-controls';

// Enable protection
apiFetch({ 
  path: '/vapt/v1/risk-002',
  method: 'POST',
  data: { 'UI-RISK-002-001': true }
});

// Get status
const status = await apiFetch({ path: '/vapt/v1/risk-002' });
```

### PHP
```php
// Get status
$response = wp_remote_get(rest_url('vapt/v1/risk-002'));
$status = json_decode(wp_remote_retrieve_body($response));

// Enable protection
wp_remote_post(rest_url('vapt/v1/risk-002'), [
  'headers' => [
    'X-WP-Nonce' => wp_create_nonce('wp_rest'),
    'Content-Type' => 'application/json'
  ],
  'body' => json_encode([ 'UI-RISK-002-001' => true ])
]);
```

### cURL
```bash
# Enable with nonce
NONCE=$(curl -s https://example.com/wp-admin/admin-ajax.php?action=rest-nonce)
curl -X POST \
  -H "X-WP-Nonce: $NONCE" \
  -H "Content-Type: application/json" \
  -d '{"UI-RISK-002-001": true}' \
  https://example.com/wp-json/vapt/v1/risk-002
```

## Testing

### Run Unit Tests
```bash
cd wp-content/plugins/vapt-protection-suite
./vendor/bin/phpunit --testsuite=vapt
```

### Run Integration Tests
```bash
cd examples/risk-RISK-002
./integration-test.sh
```

## Architecture

```
WordPress UI (React/Angular)
           ↓ REST API
WordPress REST Endpoints
           ↓ PHP Handlers
Enforcement Drivers
           ↓
Filesystem / Server
```

## Security

✅ Permission checks (`manage_options`)  
✅ Nonce verification (CSRF protection)  
✅ Input sanitization (WordPress REST API)  
✅ File permission validation  
✅ Automatic backups before modification  
✅ Rollback on failure  

## Troubleshooting

### File Permissions
```bash
# Fix .htaccess permissions
chmod 644 .htaccess

# Fix ownership
chown www-data:www-data .htaccess
```

### REST API 401 Unauthorized
```javascript
// Generate fresh nonce
fetch('/wp-admin/admin-ajax.php?action=rest-nonce')
  .then(r => r.text())
  .then(nonce => { /* use nonce */ });
```

## Contributing

1. Follow WordPress Coding Standards
2. Add tests for new features
3. Update documentation
4. Submit pull request

## License

MIT License - see [LICENSE](LICENSE)

## Support

Issues, questions, or contributions are welcome.

---

**Built for WordPress security professionals.**
EOF

# Create package
echo ""
echo "Creating release package..."
cd "${BUILD_DIR}"
zip -r "${OUTPUT_DIR}/${PACKAGE_NAME}.zip" . -q
cd - > /dev/null

# Generate checksums
cd "${OUTPUT_DIR}"
sha256sum "${PACKAGE_NAME}.zip" > "${PACKAGE_NAME}.zip.sha256"
md5sum "${PACKAGE_NAME}.zip" > "${PACKAGE_NAME}.zip.md5"
cd - > /dev/null

# Report
echo ""
echo "========================================="
echo "✓ Release Package Created Successfully"
echo "========================================="
echo ""
echo "Package: ${OUTPUT_DIR}/${PACKAGE_NAME}.zip"
echo "Size: $(du -h "${OUTPUT_DIR}/${PACKAGE_NAME}.zip" | cut -f1)"
echo ""
echo "SHA256: $(cat "${OUTPUT_DIR}/${PACKAGE_NAME}.zip.sha256" | cut -d' ' -f1)"
echo ""
echo "Package contents:"
echo "  - SKILL.md (enhanced v3.0.0)"
echo "  - DEVELOPER_GUIDE.md"
echo "  - WORDPRESS_REST_INTEGRATION_GUIDE.md"
echo "  - resources/ (all v3.0.0 resources)"
echo "  - scripts/ (generator and tools)"
echo "  - examples/ (example implementations)"
echo "  - docs/ (complete documentation)"
echo "  - CHANGELOG.md"
echo "  - LICENSE"
echo "  - README.md"
echo ""
echo "Next steps:"
echo "  1. Review the package contents"
echo "  2. Test the examples"
echo "  3. Deploy to your environment"
echo "  4. Generate implementations as needed"
echo ""
