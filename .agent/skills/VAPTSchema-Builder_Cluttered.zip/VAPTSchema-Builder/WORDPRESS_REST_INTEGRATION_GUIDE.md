# WordPress REST API Integration Guide
## for VAPTSchema Builder v3.0.0

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [REST API Structure](#rest-api-structure)
4. [Generating Implementations](#generating-implementations)
5. [Integration Steps](#integration-steps)
6. [Usage Examples](#usage-examples)
7. [Error Handling](#error-handling)
8. [Security Considerations](#security-considerations)
9. [Testing](#testing)
10. [Troubleshooting](#troubleshooting)

---

## Overview

The VAPTSchema Builder v3.0.0 now generates **full WordPress REST API compatible implementations** for VAPT security controls. Each risk includes:

- **REST API endpoints** for management and verification
- **PHP implementation code** ready to deploy
- **Automated test suites** for validation
- **Integration scripts** for CI/CD

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   WordPress Admin                       │
│                   (React/Angular UI)                    │
└───────────────────────┬─────────────────────────────────┘
                        │ REST API Calls
                        ▼
┌─────────────────────────────────────────────────────────┐
│              WordPress REST API Endpoints               │
│              /wp-json/vapt/v1/*                         │
│                                                          │
│  • GET  /vapt/v1/risk-{nnn}           (Get status)      │
│  • POST /vapt/v1/risk-{nnn}           (Update)          │
│  • DELETE /vapt/v1/risk-{nnn}         (Remove)          │
│  • GET  /vapt/v1/risk-{nnn}/verify   (Verify)          │
│  • POST /vapt/v1/risk-{nnn}/test     (Test)            │
└───────────────────────┬─────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────┐
│              VAPT Risk Handler Classes                  │
│              (class-vapt-risk-{nnn}.php)                │
│                                                          │
│  • REST registration                                     │
│  • Request validation                                    │
│  • Permission checks                                     │
│  • Enforcement logic                                     │
│  • Verification tests                                    │
└───────────────────────┬─────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────┐
│              Enforcement Drivers                        │
│                                                          │
│  • .htaccess manipulation                                 │
│  • wp-config.php modification                            │
│  • PHP hooks (actions/filters)                           │
│  • WordPress Options API                                 │
│  • Cloudflare WAF API                                    │
│  • Nginx/Apache/Caddy config writers                     │
└───────────────────────┬─────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────┐
│              WordPress Filesystem / System               │
│                                                          │
│  • .htaccess, wp-config.php                              │
│  • vapt-functions.php                                     │
│  • nginx.conf, web.config, Caddyfile                     │
│  • wp_options table                                       │
└─────────────────────────────────────────────────────────┘
```

---

## REST API Structure

### Standard Endpoints

#### Risk Management Endpoint

```
GET|POST|DELETE /wp-json/vapt/v1/risk-{nnn}
```

**GET - Retrieve Status**
```bash
curl -X GET \
  -H "X-WP-Nonce: <nonce>" \
  https://example.com/wp-json/vapt/v1/risk-002
```

**Response:**
```json
{
  "UI-RISK-002-001": true,
  "status": "applied",
  "last_verified": "2024-01-19T10:30:00+00:00",
  "last_updated": "2024-01-19T10:20:00+00:00",
  "enforcement_details": {
    "driver": "htaccess",
    "target_file": "/var/www/html/.htaccess",
    "insertion_point": "beginning_of_file",
    "markers_present": true
  },
  "verification_result": {
    "success": true,
    "blocked": true,
    "test_url": "https://example.com/xmlrpc.php",
    "status_code": 403,
    "message": "xmlrpc.php is properly blocked",
    "timestamp": "2024-01-19T10:30:00+00:00"
  }
}
```

**POST - Update Protection**
```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -H "X-WP-Nonce: <nonce>" \
  -d '{"UI-RISK-002-001": true}' \
  https://example.com/wp-json/vapt/v1/risk-002
```

**Response:**
```json
{
  "success": true,
  "UI-RISK-002-001": true,
  "status": "applied",
  "message": "xmlrpc.php protection updated successfully",
  "verification_result": {
    "success": true,
    "blocked": true,
    "status_code": 403,
    "message": "xmlrpc.php is properly blocked"
  }
}
```

**DELETE - Remove Protection**
```bash
curl -X DELETE \
  -H "X-WP-Nonce: <nonce>" \
  https://example.com/wp-json/vapt/v1/risk-002
```

**Response:**
```json
{
  "success": true,
  "message": "xmlrpc.php protection removed successfully",
  "rolled_back": true
}
```

#### Verification Endpoint

```
GET /wp-json/vapt/v1/risk-{nnn}/verify
```

**Response:**
```json
{
  "success": true,
  "status": "applied",
  "message": "All verification checks passed",
  "checks": [
    {
      "name": "File Markers Present",
      "passed": true
    },
    {
      "name": "End-to-End Test",
      "passed": true,
      "status_code": 403
    }
  ],
  "timestamp": "2024-01-19T10:30:00+00:00"
}
```

#### Test Endpoint

```
POST /wp-json/vapt/v1/risk-{nnn}/test
```

**Request:**
```json
{
  "test_url": "https://example.com/xmlrpc.php"
}
```

**Response:**
```json
{
  "blocked": true,
  "status_code": 403,
  "response_time": 156,
  "message": "xmlrpc.php is properly blocked"
}
```

---

## Generating Implementations

### Step 1: Generate Schema

Use the VAPTSchema Builder skill:

```
Generate complete implementation bundle for RISK-002
```

### Step 2: Review Output Bundle

The skill generates:

```
risk-RISK-002/
├── schema.json                 # Interface schema
├── implementation.php          # PHP handler class
├── rest_schema.json            # REST API schema
├── test_suite.php              # PHPUnit tests
├── integration-test.sh         # Integration tests
├── documentation.md            # Risk-specific docs
└── integration.yaml            # CI/CD snippet
```

### Step 3: Install Implementation

#### Method A: Manual Installation

1. Copy `implementation.php` to:
   ```
   wp-content/plugins/vapt-protection-suite/handlers/class-vapt-risk-002.php
   ```

2. Register handler in main plugin file:
   ```php
   // In vapt-protection-suite.php
   require_once plugin_dir_path(__FILE__) . 'handlers/class-vapt-risk-002.php';
   ```

3. Activate handler:
   ```php
   VAPT_RISK_002_Handler::get_instance();
   ```

#### Method B: Bulk Installation Script

```bash
# Run from plugin directory
./scripts/install-all-risks.sh
```

---

## Integration Steps

### Prerequisites

1. WordPress 5.6+ with REST API enabled
2. PHP 7.4+ or 8.0+
3. File system write permissions
4. `manage_options` capability required

### Database Schema

#### Option Storage

Each risk stores settings in `wp_options`:

```sql
-- vapt_{nnn}_settings
SELECT * FROM wp_options 
WHERE option_name = 'vapt_002_settings'
```

**Structure:**
```json
{
  "UI-RISK-002-001": true,
  "status": "applied",
  "last_verified": "2024-01-19T10:30:00+00:00",
  "updated_at": "2024-01-19T10:20:00+00:00",
  "verification_result": {...}
}
```

#### Optional Custom Table

```sql
CREATE TABLE wp_vapt_risk_status (
  id bigint(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  risk_id varchar(20) NOT NULL,
  status enum('applied','not_applied','partial','error'),
  settings json,
  last_verified datetime,
  created_at datetime DEFAULT CURRENT_TIMESTAMP,
  updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY (risk_id)
);
```

### Plugin Initialization

```php
<?php
/**
 * VAPT Protection Suite
 * Main Plugin File
 */

defined('ABSPATH') || exit;

// Define constants
define('VAPT_VERSION', '3.0.0');
define('VAPT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VAPT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Autoload classes
spl_autoload_register(function($class) {
    $prefix = 'VAPT_Protection_Suite\\';
    $base_dir = VAPT_PLUGIN_DIR . 'includes/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . 'class-' . str_replace('_', '-', strtolower($relative_class)) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Initialize risk handlers
function vapt_init_handlers() {
    $handlers = [
        'RISK-002' => '\\VAPT_Protection_Suite\\Handlers\\RISK_002',
        'RISK-003' => '\\VAPT_Protection_Suite\\Handlers\\RISK_003',
        // ... more risks
    ];
    
    foreach ($handlers as $risk_id => $handler_class) {
        if (class_exists($handler_class)) {
            new $handler_class();
        }
    }
}
add_action('plugins_loaded', 'vapt_init_handlers');

// Admin menu
require_once VAPT_PLUGIN_DIR . 'admin/class-admin-menu.php';
```

---

## Usage Examples

### Example 1: Enable Protection via REST API

```javascript
// In React/Angular component
const enableProtection = async (riskId) => {
  const nonce = wpApiSettings.nonce;
  
  const response = await fetch(`/wp-json/vapt/v1/risk-${riskId}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': nonce
    },
    body: JSON.stringify({
      [`UI-${riskId}-001`]: true
    })
  });
  
  const data = await response.json();
  
  if (data.success) {
    console.log('Protection enabled:', data.status);
  } else {
    console.error('Failed:', data.message);
  }
};

// Usage
enableProtection('RISK-002');
```

### Example 2: Get All Risk Statuses

```javascript
const getAllRisks = async () => {
  const riskIds = ['RISK-002', 'RISK-003', 'RISK-020'];
  
  const statuses = await Promise.all(
    riskIds.map(async (id) => {
      const response = await fetch(`/wp-json/vapt/v1/risk-${id}`);
      return await response.json();
    })
  );
  
  return Object.fromEntries(
    riskIds.map((id, i) => [id, statuses[i]])
  );
};
```

### Example 3: Bulk Operations

```php
<?php
// PHP - Bulk enable multiple risks
function vapt_bulk_enable_risks($risk_ids) {
    $results = [];
    
    foreach ($risk_ids as $risk_id) {
        $endpoint = rest_url("vapt/v1/risk-{$risk_id}");
        $component_id = "UI-{$risk_id}-001";
        
        $response = wp_remote_post($endpoint, [
            'headers' => [
                'X-WP-Nonce' => wp_create_nonce('wp_rest'),
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([$component_id => true])
        ]);
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $results[$risk_id] = $body['success'] ?? false;
    }
    
    return $results;
}
```

---

## Error Handling

### Standard Error Responses

```json
{
  "code": "rest_forbidden",
  "message": "Sorry, you are not allowed to do that.",
  "data": {
    "status": 403
  }
}
```

### Error Codes

| Code | HTTP | Description |
|------|------|-------------|
| `rest_forbidden` | 403 | Permission denied |
| `rest_invalid_param` | 400 | Invalid request parameters |
| `enforcement_failed` | 500 | Enforcement application failed |
| `file_not_writable` | 500 | Target file not writable |
| `rollback_failed` | 500 | Rollback failed |
| `verification_failed` | 500 | Verification check failed |
| `invalid_method` | 405 | HTTP method not allowed |

### Handling Errors in Frontend

```javascript
const handleApiError = (error) => {
  if (error.status === 403) {
    showNotification('Permission denied', 'error');
  } else if (error.status === 500) {
    showNotification('Server error. Please try again.', 'error');
  } else if (error.code === 'file_not_writable') {
    showNotification('File permissions issue. Contact administrator.', 'error');
  } else {
    showNotification('An error occurred', 'error');
  }
};
```

---

## Security Considerations

### 1. Nonce Verification

```php
// Verify nonces for AJAX
check_ajax_referer('vapt_nonce', 'nonce', true);
```

```javascript
// Include nonce in requests
const nonce = wpApiSettings.nonce;
headers['X-WP-Nonce'] = nonce;
```

### 2. Capability Checks

```php
$permission_callback = function() {
    return current_user_can('manage_options');
};
```

### 3. Rate Limiting

```php
// Implement rate limiting
add_filter('rest_authentication_errors', function($result) {
    $route = rest_get_server()->get_current_route();
    
    if (strpos($route, 'vapt/v1') !== false) {
        $user_id = get_current_user_id();
        $key = "vapt_rate_limit_{$user_id}";
        
        if (get_transient($key)) {
            return new WP_Error(
                'too_many_requests',
                'Rate limit exceeded',
                ['status' => 429]
            );
        }
        
        set_transient($key, true, MINUTE_IN_SECONDS);
    }
    
    return $result;
});
```

### 4. Input Sanitization

```php
// Always use schema-based sanitization
'sanitize_callback' => 'rest_sanitize_boolean',  // or
'sanitize_callback' => 'sanitize_text_field',
'sanitize_callback' => 'absint'
```

### 5. File Permission Checks

```php
if (!is_writable($target_file)) {
    return new WP_Error(
        'file_not_writable',
        'Target file is not writable',
        ['status' => 500]
    );
}
```

---

## Testing

### PHPUnit Tests

```bash
# Run all tests
./vendor/bin/phpunit --testsuite=vapt

# Run specific risk tests
./vendor/bin/phpunit tests/test-risk-002.php

# Watch mode
./vendor/bin/phpunit --watch tests/
```

### Integration Tests

```bash
# Run integration suite
./tests/integration-test.sh RISK-002

# With verbose output
./tests/integration-test.sh RISK-002 --verbose
```

### Manual Testing Checklist

- [ ] GET endpoint returns correct status
- [ ] POST enables protection
- [ ] POST disables protection
- [ ] DELETE removes enforcement
- [ ] Verification passes when applied
- [ ] Non-admin user gets 403
- [ ] Invalid data returns 400
- [ ] Backups are created
- [ ] Idempotency works
- [ ] Concurrent requests don't corrupt

---

## Troubleshooting

### Issue: "File not writable" Error

**Cause:** Destination file permissions issue.

**Solution:**
```bash
# Check permissions
ls -la .htaccess

# Fix permissions
chmod 644 .htaccess

# Fix ownership if needed
chown www-data:www-data .htaccess
```

### Issue: "Backup failed" Warning

**Cause:** Insufficient disk space or permission issues.

**Solution:**
```bash
# Check disk space
df -h

# Cleanup old backups
find . -name '*.vapt.bak.*' -mtime +7 -delete
```

### Issue: Enforcement Not Applied

**Cause:** Rewrites already processed by WordPress `[L]` flag.

**Solution:** Ensure `insertion_point` is `before_wordpress_rewrite`, not `after_wordpress_rewrite`.

### Issue: REST Returns 401 Unauthorized

**Cause:** Missing or invalid nonce.

**Solution:**
```javascript
// Generate fresh nonce
fetch('/wp-admin/admin-ajax.php?action=rest-nonce')
  .then(r => r.text())
  .then(nonce => {
    headers['X-WP-Nonce'] = nonce;
  });
```

### Issue: Verification Fails Despite Applied

**Cause:** Server configuration override or caching.

**Solution:**
```bash
# Clear cache
wp cache flush

# Restart web server
sudo systemctl restart apache2
# or
sudo systemctl restart nginx
```

---

## Performance Optimization

### Caching GET Responses

```php
add_action('rest_api_init', function() {
    register_rest_route('vapt/v1', '/risk-(?P<risk_id>\d+)', [
        'methods' => 'GET',
        'callback' => function($request) {
            $risk_id = $request['risk_id'];
            $cache_key = "vapt_status_{$risk_id}";
            
            $cached = get_transient($cache_key);
            if ($cached !== false) {
                return $cached;
            }
            
            $data = get_risk_status($risk_id);
            set_transient($cache_key, $data, MINUTE_IN_SECONDS * 5);
            
            return $data;
        }
    ]);
});
```

### Batch Operations

Use bulk endpoints for multiple risks:

```php
register_rest_route('vapt/v1', '/batch', [
    'methods' => 'POST',
    'callback' => 'vapt_batch_operations',
    'args' => [
        'operations' => ['type' => 'array']
    ]
]);
```

---

## CI/CD Integration

### GitHub Actions Example

```yaml
name: VAPT Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup WordPress
        uses: wordpress/setup-wordpress@v1
        
      - name: Run Integration Tests
        run: |
          ./tests/integration-test.sh RISK-002
          ./tests/integration-test.sh RISK-020
```

---

## Support

For issues and questions:

1. Check this guide
2. Review error codes above
3. Check PHP error logs
4. Enable WordPress debug: `define('WP_DEBUG', true);`
