<?php
/**
 * VAPT Protection Suite — Driver Implementation Reference
 * Version: 1.0.0
 * 
 * This file demonstrates exactly how the plugin driver should read and apply
 * vapt_driver_manifest.json entries. Every operation is explicit and traceable.
 * 
 * Usage:
 *   $driver = new VAPT_Driver( ABSPATH, plugin_dir_path(__FILE__) . 'vapt_driver_manifest.json' );
 *   $result = $driver->apply( 'RISK-003' );
 */

class VAPT_Driver {

    private string $abspath;
    private array  $manifest;

    public function __construct( string $abspath, string $manifest_path ) {
        $this->abspath  = rtrim( $abspath, '/' ) . '/';
        $this->manifest = json_decode( file_get_contents( $manifest_path ), true );
    }

    /**
     * Apply all steps for a given risk.
     * Returns array of step results: ['success'=>bool, 'message'=>string]
     */
    public function apply( string $risk_id ): array {
        if ( ! isset( $this->manifest['risks'][ $risk_id ] ) ) {
            return [['success' => false, 'message' => "Risk {$risk_id} not found in manifest"]];
        }

        $results = [];
        foreach ( $this->manifest['risks'][ $risk_id ]['steps'] as $step ) {
            $results[] = $this->execute_step( $step );
        }
        return $results;
    }

    /**
     * Rollback all steps for a given risk.
     */
    public function rollback( string $risk_id ): array {
        if ( ! isset( $this->manifest['risks'][ $risk_id ] ) ) {
            return [['success' => false, 'message' => "Risk {$risk_id} not found in manifest"]];
        }

        $results = [];
        foreach ( $this->manifest['risks'][ $risk_id ]['steps'] as $step ) {
            $results[] = $this->execute_rollback( $step );
        }
        return $results;
    }

    // ----------------------------------------------------------------
    // PRIVATE: Execute a single step
    // ----------------------------------------------------------------
    private function execute_step( array $step ): array {
        $target_file  = $this->resolve_path( $step['target_file'] );
        $write_block  = $step['write_block'];
        $check_string = $step['idempotency']['check_string'];
        $if_found     = $step['idempotency']['if_found'];   // 'skip' | 'replace'

        // 1. Create target file if it doesn't exist (e.g. uploads/.htaccess)
        if ( ! file_exists( $target_file ) ) {
            $dir = dirname( $target_file );
            if ( ! is_dir( $dir ) ) {
                return ['success' => false, 'message' => "Directory does not exist: {$dir}"];
            }
            file_put_contents( $target_file, '' );
        }

        $content = file_get_contents( $target_file );

        // 2. Idempotency — skip or replace if already present
        if ( str_contains( $content, $check_string ) ) {
            if ( $if_found === 'skip' ) {
                return ['success' => true, 'message' => "Already applied — skipped ({$step['risk_id']})"];
            }
            if ( $if_found === 'replace' ) {
                $content = $this->remove_block( $content, $step['begin_marker'], $step['end_marker'] );
            }
        }

        // 3. Backup
        if ( $step['backup_required'] ) {
            $backup = $target_file . '.vapt.bak.' . time();
            if ( ! copy( $target_file, $backup ) ) {
                return ['success' => false, 'message' => "Backup failed for {$target_file}"];
            }
        }

        // 4. Insert
        $new_content = $this->insert_block( $content, $write_block, $step['insertion'] );

        if ( $new_content === $content ) {
            return ['success' => false, 'message' => "Insertion failed — anchor not found and fallback failed"];
        }

        // 5. Write
        if ( file_put_contents( $target_file, $new_content ) === false ) {
            return ['success' => false, 'message' => "Write failed for {$target_file}"];
        }

        return ['success' => true, 'message' => "Applied {$step['risk_id']} to {$target_file}"];
    }

    // ----------------------------------------------------------------
    // PRIVATE: Rollback a single step
    // ----------------------------------------------------------------
    private function execute_rollback( array $step ): array {
        $target_file  = $this->resolve_path( $step['rollback']['target_file'] );
        $begin_marker = $step['rollback']['begin_marker'];
        $end_marker   = $step['rollback']['end_marker'];

        if ( ! file_exists( $target_file ) ) {
            return ['success' => true, 'message' => "File not found — nothing to rollback"];
        }

        $content = file_get_contents( $target_file );

        if ( ! str_contains( $content, $begin_marker ) ) {
            return ['success' => true, 'message' => "Marker not found — already rolled back"];
        }

        $new_content = $this->remove_block( $content, $begin_marker, $end_marker );

        file_put_contents( $target_file, $new_content );

        return ['success' => true, 'message' => "Rolled back {$step['risk_id']} from {$target_file}"];
    }

    // ----------------------------------------------------------------
    // PRIVATE: Insert write_block at the correct position
    // ----------------------------------------------------------------
    private function insert_block( string $content, string $write_block, array $insertion ): string {
        $anchor   = $insertion['anchor_string'];
        $position = $insertion['anchor_position'];
        $fallback = $insertion['fallback_anchor'];

        // Prepend / append — no anchor needed
        if ( $position === 'prepend' || $anchor === null ) {
            return $write_block . "\n" . $content;
        }
        if ( $position === 'append' ) {
            return $content . "\n" . $write_block . "\n";
        }

        // Anchor-based insertion
        if ( $anchor && str_contains( $content, $anchor ) ) {
            if ( $position === 'before' ) {
                return str_replace( $anchor, $write_block . "\n" . $anchor, $content );
            }
            if ( $position === 'after' ) {
                return str_replace( $anchor, $anchor . "\n" . $write_block, $content );
            }
        }

        // Anchor not found — use fallback
        if ( $fallback === 'beginning_of_file' || $fallback === 'prepend' ) {
            return $write_block . "\n" . $content;
        }
        if ( $fallback === 'end_of_file' || $fallback === 'append' ) {
            return $content . "\n" . $write_block . "\n";
        }

        // No fallback — return unchanged (driver will detect and report failure)
        return $content;
    }

    // ----------------------------------------------------------------
    // PRIVATE: Remove a VAPT block between markers (inclusive)
    // ----------------------------------------------------------------
    private function remove_block( string $content, string $begin, string $end ): string {
        // Remove everything from begin_marker to end_marker inclusive,
        // including any leading newline before begin and trailing newline after end
        $pattern = '/\n?' . preg_quote( $begin, '/' ) . '.*?' . preg_quote( $end, '/' ) . '\n?/s';
        return preg_replace( $pattern, '', $content );
    }

    // ----------------------------------------------------------------
    // PRIVATE: Resolve {ABSPATH} token in target_file
    // ----------------------------------------------------------------
    private function resolve_path( string $template ): string {
        return str_replace( '{ABSPATH}', $this->abspath, $template );
    }
}

// ================================================================
// USAGE EXAMPLE
// ================================================================
/*
add_action( 'vapt_apply_protection', function( string $risk_id ) {
    $driver  = new VAPT_Driver(
        ABSPATH,
        plugin_dir_path( __FILE__ ) . 'vapt_driver_manifest.json'
    );
    $results = $driver->apply( $risk_id );

    foreach ( $results as $result ) {
        if ( ! $result['success'] ) {
            error_log( 'VAPT Driver error: ' . $result['message'] );
        }
    }
} );

// Apply a single risk:
do_action( 'vapt_apply_protection', 'RISK-003' );

// Rollback a single risk:
$driver->rollback( 'RISK-003' );

// Apply all risks:
$manifest = json_decode( file_get_contents( 'vapt_driver_manifest.json' ), true );
foreach ( array_keys( $manifest['risks'] ) as $risk_id ) {
    do_action( 'vapt_apply_protection', $risk_id );
}
*/
