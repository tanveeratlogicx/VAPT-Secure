# VAPT Risk Catalogue — AI Agent System
## Interface Schema, Enforcer Pattern Library & AI Agent Instructions
**Version:** 1.1.0 | **Updated:** 2026-02-21 | **Source:** VAPT-Risk-Catalogue-Full-125-v3_4_1.json (125 risks)

> **v1.1 Note:** This release fixes 47 issues found during a full audit of v1.0, including three categories of critical silent `.htaccess` failures, a regex bug in author enumeration blocking, 22 metadata field mismatches, and 19 missing `wp-config.php` constant definitions. See the [What Changed in v1.1](#what-changed-in-v11) section for the full breakdown.

---

## Overview

This package transforms the VAPT Risk Catalogue into a **three-file AI Agent system** engineered to achieve **≥90% output accuracy** when generating UI component schemas and platform-specific enforcement code for 125 WordPress security risks across 8 enforcer platforms.

---

## Deliverable Files

| File | Purpose | Size |
|------|---------|------|
| `interface_schema_v1.1.json` | Complete UI schema for all 125 risks — component types, layout, actions, props, state shape, corrected platform_implementations | ~363 KB |
| `enforcer_pattern_library_v1.1.json` | Platform-specific enforcement code for all 125 risks — corrected .htaccess rules, enriched wp-config patterns, rebuilt Cloudflare/IIS/Caddy patterns | ~265 KB |
| `ai_agent_instructions_v1.1.json` | Full AI Agent system prompt, task templates, output templates, .htaccess syntax guard, updated 15-point self-check rubric, example flows | ~71 KB |
| `VAPT_Audit_Fix_Report_v1.1.md` | Full audit trail — every issue found, root cause, and fix applied | ~7 KB |

---

## Source File Analysis

### Risk Distribution
| Category | Count |
|----------|-------|
| Configuration | 78 |
| Information Disclosure | 25 |
| Authentication | 15 |
| Injection | 5 |
| API Security | 2 |

| Severity | Count |
|----------|-------|
| Critical | 9 |
| High | 36 |
| Medium | 46 |
| Low | 34 |

### Original Enforcer Coverage (from source catalogue)
| Enforcer | Risks Covered |
|----------|--------------|
| .htaccess (Apache) | 28 |
| PHP Functions | 28 |
| wp-config.php | 21 |
| fail2ban | 16 |
| Server Cron | 10 |
| WordPress | 10 |
| Nginx | 7 |
| Apache | 2 |
| Caddy (native) | 2 |

---

## Platform Coverage

This package adds **Cloudflare**, **IIS**, and **expanded Caddy** enforcement patterns for all 125 risks, in addition to correcting the existing .htaccess, wp-config, Nginx, fail2ban, and PHP patterns.

### Apache / .htaccess
All 28 .htaccess rules validated and corrected. Each rule now includes:
- `operation` — correctly typed (e.g. `add_header`, `add_files_match_block`)
- `target_file` — correct filename (`.htaccess` or `wp-content/uploads/.htaccess` for RISK-020)
- `insertion_point` — positional token, not a directive/header name
- `requires` — Apache module(s) required (e.g. `mod_headers`, `mod_rewrite`)
- `allowoverride_required` — minimum AllowOverride setting needed
- `apache_server_config` — where directives that cannot live in `.htaccess` must be placed instead
- `notes` — plain-English explanation of any caveats

### Cloudflare
Each .htaccess rule is mapped to the appropriate Cloudflare product:

| Implementation Type | Cloudflare Product | Example Risks |
|--------------------|--------------------|-|
| `transform_rule` | HTTP Response Header Modification | RISK-012, RISK-014–018, RISK-022, RISK-031–033 |
| `waf_custom_rule` | WAF Custom Rules | RISK-002, RISK-003, RISK-005, RISK-027–030 |
| `notes_only` | Origin-only — not enforceable at edge | RISK-013, RISK-023, RISK-025, RISK-026 |

### IIS (web.config)
| Implementation Type | IIS Config Section | Example Risks |
|--------------------|--------------------|-|
| `web_config_http_headers` | `<httpProtocol><customHeaders>` | All header risks |
| `web_config_request_filtering` | `<security><requestFiltering>` | File block risks, TRACE method |
| `web_config_request_filtering_extensions` | `<fileExtensions>` | Backup/log/sensitive file blocks |
| `web_config_url_rewrite` | `<rewrite><rules>` | Author enum, REST API, path blocks |
| `web_config_directory_browsing` | `<directoryBrowse enabled="false" />` | RISK-013 |
| `web_config_remove_headers` | `<requestFiltering removeServerHeader="true">` | RISK-024 |

**Requirement:** IIS URL Rewrite Module 2.1 must be installed for `web_config_url_rewrite` rules.  
**Verify:** `appcmd list module /name:RewriteModule`

### Caddy (Caddyfile v2)
| Implementation Type | Caddyfile Directive | Example Risks |
|--------------------|---------------------|-|
| `caddy_header` | `header { Name "Value" defer }` | All header risks, Server header removal |
| `caddy_respond_block` | `@matcher { } respond @matcher 403` | File blocks, path blocks, method blocks |
| `caddy_respond_extension_block` | `@matcher { path *.ext }` | Extension-based blocks |
| `caddy_file_server` | `file_server` (browse omitted) | RISK-013 directory listing |
| `native_caddy` | Direct Caddy directives | RISK-123, RISK-124 |
| `notes_only` | No Caddy equivalent | RISK-026 symlinks |

**Always run `caddy validate --config /etc/caddy/Caddyfile` before `caddy reload`.**

---

## How the AI Agent Should Use These Files

### Step 1 — Select Task Type
Four task types are defined in `ai_agent_instructions_v1.1.json`:

| Task | Use When |
|------|----------|
| `generate_ui_component_schema` | Generating UI JSON for one or more risks |
| `generate_enforcement_code` | Generating platform code for one risk + one platform |
| `generate_full_risk_package` | UI schema + all platform codes for one risk |
| `generate_bulk_schema` | All 125 risks, optionally filtered by category or severity |

### Step 2 — Schema-First Lookup
Always read `interface_schema_v1.1.json` before writing any UI output:

```
interface_schema_v1.1.risk_interfaces[RISK-XXX]
  → title, severity, category, summary
  → ui_layout { section, order, collapsible, default_expanded, card_id }
  → components[]  { component_id, type, label, default_value, on_change, dependencies }
  → actions[]     { action_id, type, label, confirmation_required, ... }
  → platform_implementations { .htaccess: { operation, target_file, requires_module, ... } }
  → available_platforms[]
```

### Step 3 — Pattern Library Lookup
Always read `enforcer_pattern_library_v1.1.json` before writing any enforcement code. **Never write enforcement code from memory.**

```
enforcer_pattern_library_v1.1.patterns[RISK-XXX]
  → htaccess_corrected   { code, wrapped_code, operation, target_file, insertion_point, requires, notes }
  → cloudflare           { implementation_type, transform_rule | waf_custom_rule, verification }
  → iis                  { implementation_type, web_config_snippet, requirements, verification }
  → caddy                { implementation_type, caddyfile_snippet, verification }
  → wp_config_enriched   { code, wrapped_code, target_constants[], insertion_rule, verification }
```

### Step 4 — Run the .htaccess Syntax Guard
Before emitting **any** `.htaccess` code, check against the `htaccess_syntax_guard` in `ai_agent_instructions_v1.1.json`.

**Hard-forbidden in .htaccess (silently ignored by Apache):**

| Directive | Reason | Correct Alternative |
|-----------|--------|---------------------|
| `TraceEnable off` | Server-level only | `RewriteCond %{REQUEST_METHOD} ^TRACE` + `RewriteRule .* - [F,L]` |
| `ServerSignature Off` | Server-level only | `Header unset Server` (mod_headers) |
| `ServerTokens Prod` | Server-level only | `Header unset Server` (mod_headers) |
| `<Directory ...>` | Silently ignored | Use `<FilesMatch>` or create `.htaccess` in the target subdirectory |
| `<VirtualHost ...>` | Server-level only | httpd.conf only |

**Required companions — always emit these before the rule:**

| Directive | Requires |
|-----------|----------|
| `RewriteRule` / `RewriteCond` | `RewriteEngine On` on the preceding line |
| `Header` | mod_headers — emit: `# Requires: sudo a2enmod headers` |
| `Options` | `AllowOverride Options` or `AllowOverride All` in server config |
| `<Files>` / `<FilesMatch>` | `AllowOverride Limit` or `AllowOverride All` |

### Step 5 — Apply the Enforcer Validation Gate
Before outputting any platform code:
1. Verify the platform is listed in `available_platforms[]` for that risk
2. Check `implementation_type` in the pattern library entry
3. If `notes_only` → output the note + suggest the closest available platform as a fallback
4. If any code type → output the code from the correct field with VAPT block markers

### Step 6 — Self-Check Rubric (Score ≥13/15 required to output)

| # | Check | Weight |
|---|-------|--------|
| 1 | All component IDs match interface_schema exactly | 2 |
| 2 | Enforcement code read from pattern library, not written from memory | 2 |
| 3 | Severity badge colors match `global_ui_config.severity_badge_colors` | 1 |
| 4 | Handler names follow naming conventions | 1 |
| 5 | Platform listed in `available_platforms` for this risk | 1 |
| 6 | VAPT block markers present in all enforcement code output | 1 |
| 7 | Verification command present and matches platform CLI | 1 |
| 8 | No forbidden patterns violated | 1 |
| 9 | **[v1.1]** No forbidden .htaccess directives in output | 2 |
| 10 | **[v1.1]** `RewriteEngine On` present before every Rewrite block | 1 |
| 11 | **[v1.1]** mod_headers requirement noted for Header directives | 1 |
| 12 | **[v1.1]** AllowOverride requirement noted for Options directives | 1 |
| 13 | **[v1.1]** `target_file` = `wp-content/uploads/.htaccess` for RISK-020 | 1 |
| 14 | **[v1.1]** IIS `<rewrite>` sections include URL Rewrite Module requirement | 1 |
| 15 | **[v1.1]** Caddy output uses v2 syntax only — no Apache directives, semicolons, or Order/Deny | 1 |

**If score < 13: identify the failing checks and regenerate before delivering output.**

---

## Enforcer Block Markers (Required in all code output)

Every enforcement code block must be wrapped with platform-appropriate markers so the plugin can locate, verify, and roll back rules precisely.

### Apache / .htaccess
```apache
# BEGIN VAPT RISK-XXX — Title of Risk
# Requires: mod_headers | AllowOverride: FileInfo
<your code here>
# END VAPT RISK-XXX
```

### IIS web.config
```xml
<!-- BEGIN VAPT RISK-XXX: Title of Risk -->
<configuration>
  ...
</configuration>
<!-- END VAPT RISK-XXX -->
```

### Caddy (Caddyfile)
```caddy
# BEGIN VAPT RISK-XXX: Title of Risk
@matcherName {
    ...
}
respond @matcherName 403
# END VAPT RISK-XXX
```

### Cloudflare (Rule description field)
```
VAPT RISK-XXX: Title of Risk
```

### wp-config.php
```php
/* BEGIN VAPT RISK-XXX */
define('CONSTANT_NAME', value);
/* END VAPT RISK-XXX */
```

### PHP Functions / Hooks
```php
// BEGIN VAPT RISK-XXX
add_action('hook_name', 'vapt_function_name');
// END VAPT RISK-XXX
```

### fail2ban
```ini
# BEGIN VAPT RISK-XXX
[jail-name]
...
# END VAPT RISK-XXX
```

---

## Insertion Point Reference

All `.htaccess` rules use one of these canonical positional tokens — never a directive name or header name:

| Token | Meaning |
|-------|---------|
| `beginning_of_file` | Very top of `.htaccess`, before any WordPress content |
| `before_wordpress_rewrite` | Immediately before the `# BEGIN WordPress` comment block |
| `after_wordpress_rewrite` | Immediately after the `# END WordPress` comment block |
| `after_rewrite_engine` | After `RewriteEngine On`, within the WordPress rewrite section |
| `end_of_file` | Appended at the very end of `.htaccess` |

**wp-config.php:** All constants must be inserted **before** the line:
```php
require_once ABSPATH . 'wp-settings.php';
```

---

## Platform Verification Commands

| Platform | Validate Config | Reload / Apply | Test Response |
|----------|----------------|----------------|---------------|
| Apache/.htaccess | `apachectl -t` | `service apache2 reload` | `curl -sI https://yoursite.com` |
| IIS | `appcmd.exe validate config` | `iisreset /restart` or App Pool Recycle | `curl -sI https://yoursite.com` |
| Caddy | `caddy validate --config /etc/caddy/Caddyfile` | `caddy reload --config /etc/caddy/Caddyfile` | `curl -sI https://yoursite.com` |
| Cloudflare | Review in Dashboard before saving | Instant (rules live on save) | `curl -sI https://yoursite.com` |
| Nginx | `nginx -t` | `nginx -s reload` | `curl -sI https://yoursite.com` |
| fail2ban | `fail2ban-client -t` | `fail2ban-client reload` | `fail2ban-client status jail-name` |
| wp-config.php | `wp config get CONSTANT` | PHP reads on next request | `wp config list` |

---

## Platform Limitations & Requirements

### Apache / .htaccess
- `AllowOverride All` or specific `AllowOverride` directives must be set in `httpd.conf` or VirtualHost for `.htaccess` rules to take effect
- `mod_rewrite` must be enabled for all `RewriteRule`/`RewriteCond` blocks: `sudo a2enmod rewrite`
- `mod_headers` must be enabled for all `Header` directives: `sudo a2enmod headers`
- `<Directory>` blocks in `.htaccess` are **silently ignored** — use `<FilesMatch>` or a per-directory `.htaccess` instead
- `TraceEnable`, `ServerSignature`, `ServerTokens` are **server-level only** — place in `httpd.conf` or VirtualHost, complement with mod_headers workarounds in `.htaccess`

### Cloudflare
- `Options -Indexes`, `TraceEnable`, `FileETag` and similar Apache directives have **no Cloudflare equivalent** — enforce at origin, mark as `notes_only`
- `Header unset Server` → use Transform Rule (available on all plans, including Free)
- Rate limiting beyond simple thresholds requires **Cloudflare Pro or higher**
- wp-config.php constants and PHP-level controls **cannot** be enforced from the Cloudflare edge
- Workers required for complex conditional logic — adds cold-start latency consideration

### IIS
- **URL Rewrite Module 2.1** must be installed for any `web_config_url_rewrite` rules — verify with `appcmd list module /name:RewriteModule`
- `removeServerHeader="true"` requires **IIS 10.0+**
- PHP `php_flag engine off` has no IIS equivalent — use `requestFiltering` to block `.php` file extensions instead
- `web.config` changes take effect immediately without restart in most configurations
- `AllowOverride` is an Apache concept — IIS uses the `web.config` hierarchy exclusively

### Caddy
- **Caddyfile v2 syntax only** — v1 syntax is incompatible
- Directory listing is **disabled by default** in `file_server` — explicitly verify `browse` is not present
- Named matchers must use **alphanumeric identifiers only** — no hyphens (the pattern library uses risk IDs with hyphens removed, e.g. `risk001`, `risk014`)
- For Caddy acting as reverse proxy to PHP-FPM, some security headers must be set at the PHP/WordPress layer, not Caddy
- `admin off` in Caddyfile disables the Caddy admin API — do not use if deploying via API-based config management

---

## Naming Conventions (AI Agent)

All generated names must follow these patterns exactly to avoid collisions and allow the plugin to locate handlers:

| Entity | Pattern | Example |
|--------|---------|---------|
| React component | `Risk{NNN}{TitleCamelCase}` | `Risk001WpCronProtection` |
| Toggle handler | `handleRISK{NNN}ToggleChange` | `handleRISK014ToggleChange` |
| Dropdown handler | `handleRISK{NNN}DropdownChange` | `handleRISK003DropdownChange` |
| Settings key | `vapt_risk_{nnn}_settings` | `vapt_risk_001_settings` |
| REST endpoint | `/wp-json/vapt/v1/{risk-id-lower}` | `/wp-json/vapt/v1/risk-001` |
| Action ID | `ACTION-{NNN}-{SEQ}` | `ACTION-001-001` |
| Component ID | `UI-RISK-{NNN}-{SEQ}` | `UI-RISK-001-001` |
| Caddy matcher | `risk{nnn}` (no hyphens) | `@risk023` |
| VAPT PHP function | `vapt_{descriptive_name}` | `vapt_disable_xmlrpc` |

---

## Usage Examples

### Example 1 — Single risk, .htaccess enforcement
**Prompt:** `Generate .htaccess enforcement for RISK-023 (Trace Method Enabled)`

**Correct agent workflow:**
1. Read `enforcer_pattern_library_v1.1.patterns.RISK-023.htaccess_corrected`
2. Run `.htaccess syntax guard` — `TraceEnable off` is **forbidden**
3. Read `corrected_code`: mod_rewrite TRACE blocker (already fixed in library)
4. Emit pre-flight comment: `# Requires: mod_rewrite | AllowOverride: FileInfo or All`
5. Output the wrapped code block with `# BEGIN VAPT RISK-023` / `# END VAPT RISK-023` markers
6. Append server config note: `# For authoritative enforcement, also add: TraceEnable off to httpd.conf`
7. Append verification: `apachectl -t && curl -X TRACE -sI https://yoursite.com | grep HTTP`
8. Self-check — rubric checks 9 ✓ (no forbidden directives), 10 ✓ (RewriteEngine On present) → 15/15 → output

---

### Example 2 — RISK-020, uploads PHP block (critical target_file)
**Prompt:** `Generate .htaccess protection for RISK-020 (PHP File Execution in Uploads)`

**Correct agent workflow:**
1. Read `enforcer_pattern_library_v1.1.patterns.RISK-020.htaccess_corrected`
2. Read `target_file`: **`wp-content/uploads/.htaccess`** (not the root `.htaccess`)
3. Run `.htaccess syntax guard` — `<Directory>` is **forbidden**; corrected code uses `<FilesMatch>`
4. Emit: "⚠ This rule must be placed in `wp-content/uploads/.htaccess` — a separate file in the uploads directory. A rule in the WordPress root `.htaccess` will not prevent PHP execution in subdirectories."
5. Output the `<FilesMatch "\\.php$">` block with VAPT markers
6. Append Apache 2.4+ alternative: `Require all denied`
7. Self-check — rubric check 13 ✓ (target_file = uploads/.htaccess) → 15/15 → output

---

### Example 3 — Full risk package across all platforms
**Prompt:** `Generate the full risk package for RISK-022 (Missing Content-Security-Policy Header) for platforms: .htaccess, Cloudflare, IIS, Caddy`

**Agent workflow:**
1. Load `interface_schema_v1.1.risk_interfaces.RISK-022` → UI schema
2. Load `enforcer_pattern_library_v1.1.patterns.RISK-022` for all 4 platforms

**.htaccess output:**
```apache
# BEGIN VAPT RISK-022 — Missing Content-Security-Policy Header
# Requires: mod_headers | AllowOverride: FileInfo or All
# Enable: sudo a2enmod headers && sudo service apache2 restart
Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'; frame-ancestors 'none';"
# END VAPT RISK-022
# Note: Tune CSP to your plugin/theme requirements. Use Content-Security-Policy-Report-Only first.
```

**Cloudflare Transform Rule:**
```
Product: Transform Rules → Modify Response Header
Action: Set
Name: Content-Security-Policy
Value: default-src 'self'; script-src 'self' 'unsafe-inline'; ...
Expression: true (apply to all requests)
```

**IIS web.config:**
```xml
<!-- BEGIN VAPT RISK-022: Missing Content-Security-Policy Header -->
<configuration>
  <system.webServer>
    <httpProtocol>
      <customHeaders>
        <remove name="Content-Security-Policy" />
        <add name="Content-Security-Policy" value="default-src 'self'; ..." />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
<!-- END VAPT RISK-022 -->
```

**Caddy:**
```caddy
# BEGIN VAPT RISK-022: Missing Content-Security-Policy Header
header {
    Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; ..."
    defer
}
# END VAPT RISK-022
```

3. Self-check all four outputs → 15/15 each → deliver package

---

### Example 4 — Bulk enforcement for a category
**Prompt:** `Generate Cloudflare WAF rules for all Authentication risks`

**Agent workflow:**
1. Filter `interface_schema_v1.1.risk_interfaces` where `category == "Authentication"`
2. For each risk: load `enforcer_pattern_library_v1.1.patterns[risk_id].cloudflare`
3. Group by `implementation_type`:
   - `waf_custom_rule` → output WAF expression
   - `transform_rule` → output Transform Rule config
   - `notes_only` → output note, skip code
4. Sort output by `priority` descending (read from `interface_schema.risk_interfaces[rid].priority`)
5. Self-check each entry → deliver ordered list

---

## What Changed in v1.1

### Critical .htaccess Failures Fixed (3 risks)

| Risk | v1.0 Bug | v1.1 Fix |
|------|----------|----------|
| RISK-020 | `<Directory>` block silently ignored in .htaccess | Replaced with `<FilesMatch "\\.php$">` in `wp-content/uploads/.htaccess` |
| RISK-023 | `TraceEnable off` silently ignored in .htaccess | Replaced with `mod_rewrite` TRACE method blocker |
| RISK-024 | `ServerSignature Off` silently ignored in .htaccess | Replaced with `mod_headers` Server header unsetting |

### Regex Bug Fixed (1 risk)

| Risk | v1.0 Bug | v1.1 Fix |
|------|----------|----------|
| RISK-005 | `author=\d` only blocked author IDs 1–9 | Corrected to `author=\d+` to match all numeric IDs |

### Missing RewriteEngine On (2 risks)
RISK-003 and RISK-005 had `RewriteRule`/`RewriteCond` blocks without a preceding `RewriteEngine On`. Apache silently skips rewrite rules when this is absent.

### Metadata Field Corrections (22 risks)
- `insertion_point` fields were set to header/directive names (e.g. `"X-Frame-Options"`, `"TraceEnable"`) instead of positional tokens — corrected to `"beginning_of_file"` or appropriate token
- `file` fields were set to operation names (e.g. `"add_header"`, `"add_directive"`) instead of the target filename — corrected to `".htaccess"` or `"wp-content/uploads/.htaccess"`

### mod_headers Requirements Documented (9 risks)
RISK-012, RISK-014–018, RISK-022, RISK-024, RISK-031–033: All Header directives now carry `requires_module`, `module_enable_cmd`, and `allowoverride_required` fields.

### AllowOverride Requirements Documented (3 risks)
RISK-013, RISK-023, RISK-026 now carry explicit `allowoverride_required` notes.

### wp-config.php Enrichment (19 risks)
19 risks using `op=constant_exists` were missing `target_constant` and `target_value` fields. All 21 wp-config risks now include `target_constants[]`, `target_values[]`, `insertion_rule`, and `verification.command`.

### Pattern Extensions (3 risks)
| Risk | Extension |
|------|-----------|
| RISK-019 | Added `.ini`, `.yml`, `.yaml`, `.conf` to FilesMatch pattern |
| RISK-029 | Added `.swp`, `.sql`, `.dump` to FilesMatch pattern |
| RISK-030 | Added `.error_log`, `.access_log` to FilesMatch pattern |

### New: .htaccess Syntax Guard in AI Agent Instructions
`ai_agent_instructions_v1.1.json` includes a `htaccess_syntax_guard` section covering:
- Forbidden directives with reason and correct alternative
- Required companion directives per rule type
- Valid vs invalid block directive types in .htaccess context
- Canonical insertion point token definitions
- Apache 2.4+ syntax compatibility notes
- Per-risk `target_file` rules

### Self-Check Rubric Expanded
- v1.0: 8 checks, max score 10, threshold ≥9
- v1.1: 15 checks, max score 15, threshold **≥13**
- 7 new checks added covering the .htaccess guard, module requirements, target_file validation, IIS requirements, and Caddy v2 syntax

---

*Generated by VAPT Risk Catalogue Transformation System v1.1.0*
