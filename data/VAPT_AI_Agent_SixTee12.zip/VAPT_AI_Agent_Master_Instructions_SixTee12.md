# VAPT AI Agent — Master Instructions
## Transform Risk Catalogue → Interface Schema JSON

**Document Version:** 1.0.0  
**Quality Target:** ≥ 90% Output Accuracy  
**Plugin:** WordPress VAPT Protection Suite (v3.4.0)  
**Framework:** React / WordPress Admin + Tailwind CSS  

---

## 1. MISSION STATEMENT

You are an AI Agent responsible for transforming the **VAPT Risk Catalogue JSON**
(`VAPT-SixTee-Risk-Catalogue-12-EntReady_v3_4.json`) into a production-ready
**Interface Schema JSON** (`VAPT_Interface_Schema_Output.json`).

The Interface Schema is consumed directly by the WordPress React admin UI to render
security protection panels for each of the 12 VAPT risks.

**Your output quality MUST reach ≥ 90% accuracy. The three files below are your
authoritative references — do NOT deviate from them:**

| Reference File | Purpose |
|---|---|
| `VAPT_Enforcer_Pattern_Library.json` | Canonical code templates, operation IDs, quality rules |
| `VAPT_Interface_Schema_Spec.json` | Field-by-field contract for the output schema |
| `VAPT-SixTee-Risk-Catalogue-12-EntReady_v3_4.json` | Source data (read-only) |

---

## 2. MANDATORY PRE-FLIGHT CHECKLIST

Before writing a single field of output, verify you have loaded and understood:

- [ ] All 6 enforcer types and their valid operations from the Pattern Library
- [ ] All 10 Quality Enforcement Rules (QER-001 through QER-010)
- [ ] The `RiskInterfaceDefinition` structure from the Schema Spec
- [ ] The `severity_color_system` and `status_color_system` lookup tables
- [ ] The `api_endpoint_patterns` for all API URLs
- [ ] The `field_derivation_rules` for computed fields

---

## 3. THE 10 QUALITY ENFORCEMENT RULES (QER)

These rules are NON-NEGOTIABLE. Violations of CRITICAL rules = automatic output rejection.

### QER-001 — Enforcer Constant Fidelity ⛔ CRITICAL
The `enforcer_type` field must EXACTLY match one of:
```
"wp-config.php" | ".htaccess" | "PHP Functions" | "WordPress Core" | "fail2ban" | "Nginx"
```
Any variation (e.g., "htaccess", "WordPress-Core", "Fail2Ban") is a CRITICAL VIOLATION.

### QER-002 — Operation-to-Enforcer Contract ⛔ CRITICAL
Each operation must only appear under its assigned enforcer. Whitelist:
```
wp-config.php    → add_constant, remove_constant
.htaccess        → add_directive_block, add_rewrite_rule, add_rewrite_cond, add_files_block, add_header
PHP Functions    → add_action_hook, add_filter_hook
WordPress Core   → add_filter_hook
fail2ban         → add_jail_config, disable_jail
Nginx            → modify_server_tokens
```

### QER-003 — Zero Unsubstituted Placeholders ⛔ CRITICAL
Generated code strings must contain NO un-substituted template placeholders.
Pattern to scan for: `\{[A-Z_]+\}`
If found → replace with actual value from source data.

✅ CORRECT: `define('DISABLE_WP_CRON', true);`  
❌ WRONG:   `define('{CONSTANT_NAME}', {VALUE});`

### QER-004 — PHP Function Prefix Convention ⚠️ HIGH
All PHP callback functions for `PHP Functions` and `WordPress Core` enforcers
MUST be prefixed with `vapt_`.

✅ CORRECT: `function vapt_rate_limit_password_reset()`  
❌ WRONG:   `function rate_limit_password_reset()`

### QER-005 — backup_required Always True ⚠️ HIGH
Every `enforcement_config.backup_required` field must be `true`.

### QER-006 — Verification Command Present ⚠️ HIGH
Every risk's `enforcement_config.verification.commands` array must contain ≥ 1
entry with `command` and `expected_result` populated from `verification_engine.advanced_verification.methods`.

### QER-007 — Rollback Steps Required ⚠️ HIGH
Every risk's `enforcement_config.rollback_steps` must contain ≥ 1 step sourced from
`protection.rollback_steps` in the source catalog.

### QER-008 — UI Handler Naming Convention ⚠️ MEDIUM
`on_change_handler` values must follow: `handle{RISK_ID_CAMEL}{Type}Change`
Examples: `handleRISK001ToggleChange`, `handleRISK007DropdownChange`

### QER-009 — CVSS Score Fidelity ⚠️ MEDIUM
`display.cvss_score` must match `severity.cvss_score` from source verbatim. No rounding.

### QER-010 — Relationship Integrity 💡 LOW
All `risk_id` values in `display.related_risk_ids` must exist in the risk catalog
(RISK-001 through RISK-012).

---

## 4. STEP-BY-STEP GENERATION WORKFLOW

Execute these steps IN ORDER for EACH of the 12 risks.

### Step 1 — Extract Source Fields
From `risk_catalog[n]`, extract and map:
```
risk_id             → direct copy
title               → direct copy
category            → direct copy
severity.level      → display.severity_level
severity.cvss_score → display.cvss_score (QER-009: exact match)
severity.cvss_vector → display.cvss_vector
owasp_mapping.owasp_top_10_2025 → display.owasp_tag
owasp_mapping.cwe   → display.cwe_tags
description.summary → display.summary
relationships.risk_family → display.risk_family
relationships.related_risks → display.related_risk_ids (QER-010)
protection.priority → display.priority_score
ui_configuration.layout.section → display.ui_section
ui_configuration.layout.order   → display.ui_order
```

### Step 2 — Derive Badge Config
Look up `display.severity_level` in the Pattern Library `severity_color_system`:
```
critical → bg-red-100 / text-red-800 / border-red-200 / shield-x
high     → bg-orange-100 / text-orange-800 / border-orange-200 / shield-alert
medium   → bg-yellow-100 / text-yellow-800 / border-yellow-200 / shield-half
low      → bg-blue-100 / text-blue-800 / border-blue-200 / shield-check
```
Populate `display.badge_config` with all 4 fields.

### Step 3 — Derive Category Icon
```
Configuration       → "settings"
Authentication      → "lock"
Information Disclosure → "eye-off"
API Security        → "code"
Transport Security  → "shield"
```

### Step 4 — Build Status Engine
```
check_id            ← verification_engine.automated_checks[0].check_id
check_method        ← verification_engine.automated_checks[0].method
api_status_endpoint ← "/wp-json/vapt-secure/v1/status/{risk_id_lower}"
polling_enabled     ← verification_engine.continuous_monitoring.enabled
polling_frequency   ← verification_engine.continuous_monitoring.frequency
alert_on_failure    ← verification_engine.continuous_monitoring.alert_on_failure
auto_remediate      ← verification_engine.continuous_monitoring.auto_remediate
verification_commands ← ALL items from verification_engine.advanced_verification.methods
pass_indicator.message ← reporting.status_indicators[0].message
```

### Step 5 — Build Control Panel
Split `ui_configuration.components` into:
- `primary_toggle` = first component where `type == "toggle"`
- `secondary_controls` = all remaining components

For each secondary control, map:
```
component_id, type, label, default_value, options, on_change → on_change_handler, validation
```

For each action in `ui_configuration.actions`, add `api_endpoint`:
```
"enable"    → "/wp-json/vapt-secure/v1/protection/{risk_id_lower}/enable"
"disable"   → "/wp-json/vapt-secure/v1/protection/{risk_id_lower}/disable"
"scan"      → "/wp-json/vapt-secure/v1/scan/{risk_id_lower}"
"test"      → "/wp-json/vapt-secure/v1/scan/{risk_id_lower}/test"
"export"    → "/wp-json/vapt-secure/v1/report/{risk_id_lower}/export"
"remediate" → "/wp-json/vapt-secure/v1/protection/{risk_id_lower}/remediate"
```

**Always add a Scan Now button** if no scan action exists in ui_configuration.actions.

### Step 6 — Build Enforcement Config ← MOST CRITICAL STEP
This is where most AI errors occur. Follow precisely:

**6a.** Read `protection.automated_protection.implementation_steps[0]`
**6b.** Extract `enforcer` field → apply QER-001 (exact match check)
**6c.** Extract `operation` field → apply QER-002 (operation-enforcer whitelist)
**6d.** Look up `enforcer` in Pattern Library → get `enforcer_id`
**6e.** Look up `operation` in Pattern Library → get `operation_id`
**6f.** Set `implementation_code.code` from `code_examples[0].code` → apply QER-003

**Enforcer-specific rules:**

| Enforcer | Special Rule |
|---|---|
| `wp-config.php` | Include `insertion_point: "before_wp_settings"` |
| `.htaccess` | Set `backup_required: true`; include `insertion_point` |
| `PHP Functions` | All function names must have `vapt_` prefix (QER-004) |
| `WordPress Core` | Use `operation_id: "OP-WPC-FILTER-001"` for filter hooks |
| `fail2ban` | Add extra form fields: `max_retry` (int, 1-10), `ban_time` (int, 300-86400), `find_time` (int, 60-3600) |
| `Nginx` | Mark as requiring manual server deployment; generate 3 code variants (Apache/Nginx/.htaccess) |

**6g.** Always set `backup_required: true` (QER-005)
**6h.** Populate `verification.commands` from `verification_engine.advanced_verification.methods` where `automated == true` (QER-006)
**6i.** Copy `rollback_steps` from `protection.rollback_steps` (QER-007)
**6j.** Set `pattern_library_ref: "VAPT_Enforcer_Pattern_Library.json → enforcer_types.{enforcer}"`

### Step 7 — Build Form Schema
For each `ui_configuration.component`, create a form field:
```
toggle    → type: "boolean"
dropdown  → type: "select", include options array
text      → type: "string", include validation.pattern if present
checkbox  → type: "boolean"
slider    → type: "integer", include validation.min and validation.max
```
`wp_option_key` = `"vapt_{risk_id_lower}_{component_type}_{component_id_suffix}"`

For `fail2ban` risks, add 3 extra fields (max_retry, ban_time, find_time).
For HSTS risk, add hsts_max_age field (min: 31536000).

### Step 8 — Build Dashboard Card
Compact summary object for the main dashboard:
```
card_id           = "card-{risk_id_lower}"
title             = title truncated to 60 characters
category_icon     = derived in Step 3
severity_badge    = badge_config from Step 2
status_indicator  = STATUS_COLORS['unknown'] (initial state before first scan)
compliance_tags   = flatten [pci_dss, gdpr, nist_csf] arrays into single string array
```

### Step 9 — Build Detail View (5 Tabs)
Populate each tab from the corresponding source section:
```
overview    ← description, attack_scenario, affected_components, business_impact, owasp_mapping
testing     ← testing.verification_steps, testing.test_payloads, advanced_verification.methods
remediation ← protection.implementation_steps, code_examples, manual_steps, rollback_steps
compliance  ← owasp_mapping, evidence_requirements.compliance_frameworks
evidence    ← evidence_requirements.evidence_types, reporting.export_formats
```

### Step 10 — Add Category Enhancements
Apply category-specific UI enhancements:
```
"Authentication"         → {login_counter_enabled: true, ip_block_interface: true, password_policy_indicator: true}
"Configuration"          → {config_file_preview: true, htaccess_visualizer: true}
"Information Disclosure" → {exposed_endpoints_list: true, quick_block_toggles: true}
"API Security"           → {api_request_logger: true, endpoint_whitelist_manager: true, rate_limit_configurator: true}
```

### Step 11 — Self-Validation Pass
Before emitting the object, run this internal check:
```
[ ] QER-001: enforcer_type is one of 6 valid values?
[ ] QER-002: operation is in the allowed list for this enforcer?
[ ] QER-003: code field has no {PLACEHOLDER} patterns?
[ ] QER-004: all PHP functions start with vapt_?
[ ] QER-005: backup_required is true?
[ ] QER-006: at least 1 verification command present?
[ ] QER-007: at least 1 rollback step present?
[ ] QER-008: on_change_handler follows naming convention?
[ ] QER-009: cvss_score matches source exactly?
[ ] QER-010: all related_risk_ids exist in catalog?
```
If any CRITICAL (QER-001, QER-002, QER-003) check fails → STOP and fix before emitting.

---

## 5. RISK-BY-RISK GENERATION GUIDE

Use this quick-reference for each risk's enforcer/operation:

| Risk ID | Enforcer | Operation | Op ID | Key Fields |
|---------|----------|-----------|-------|-----------|
| RISK-001 | wp-config.php | add_constant | OP-WPC-001 | DISABLE_WP_CRON = true |
| RISK-002 | .htaccess | add_directive_block | OP-HTA-001 | target_file: xmlrpc.php |
| RISK-003 | .htaccess | add_rewrite_rule | OP-HTA-002 | pattern: ^wp-json/wp/v2/users |
| RISK-004 | PHP Functions | add_action_hook | OP-PHP-001 | hook: login_init |
| RISK-005 | .htaccess | add_rewrite_cond | OP-HTA-003 | pattern: author=\d |
| RISK-006 | WordPress Core | add_filter_hook | OP-WPC-FILTER-001 | hook: rest_authentication_errors |
| RISK-007 | fail2ban | add_jail_config | OP-F2B-001 | jail: wordpress-login; add maxretry/bantime/findtime fields |
| RISK-008 | PHP Functions | add_filter_hook | OP-PHP-002 | hook: login_errors |
| RISK-009 | PHP Functions | add_action_hook | OP-PHP-001 | hook: wp_enqueue_scripts |
| RISK-010 | Nginx | modify_server_tokens | OP-NGX-001 | 3 variants: Apache/Nginx/.htaccess |
| RISK-011 | .htaccess | add_files_block | OP-HTA-004 | target_file: readme.html |
| RISK-012 | .htaccess | add_header | OP-HTA-005 | header: Strict-Transport-Security; min max-age: 31536000 |

---

## 6. API ENDPOINT DERIVATION

`{risk_id_lower}` = `risk_id.toLowerCase().replace('-', '_')`  
Examples: `RISK-001` → `risk_001`, `RISK-012` → `risk_012`

| Action | Pattern | Example (RISK-001) |
|--------|---------|-------------------|
| Get Status | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/status/{risk_id_lower}` | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/status/risk_001` |
| Enable | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/protection/{risk_id_lower}/enable` | `…/risk_001/enable` |
| Disable | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/protection/{risk_id_lower}/disable` | `…/risk_001/disable` |
| Scan | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/scan/{risk_id_lower}` | `…/scan/risk_001` |
| Logs | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/logs/{risk_id_lower}` | `…/logs/risk_001` |
| Export | `https://{{SITE_URL}}/wp-json/vapt-secure/v1/report/{risk_id_lower}/export` | `…/report/risk_001/export` |

---

## 7. ENFORCER CODE GENERATION RULES

### wp-config.php
```php
// VAPT Protection: {risk_id} - {title}
define('{CONSTANT_NAME}', {VALUE});
```
- Boolean: `true` / `false` (NO quotes)
- String: `'value'` (single quotes)
- Integer: `123` (no quotes)

### .htaccess — Files Block
```apache
# VAPT Protection: {risk_id}
<Files {TARGET_FILE}>
Order Deny,Allow
Deny from all
</Files>
```

### .htaccess — RewriteRule
```apache
# VAPT Protection: {risk_id}
RewriteEngine On
RewriteRule {PATTERN} - [F,L]
```

### .htaccess — RewriteCond + RewriteRule
```apache
# VAPT Protection: {risk_id}
RewriteEngine On
RewriteCond %{QUERY_STRING} {PATTERN} [NC]
RewriteRule ^ - [F,L]
```

### .htaccess — Security Header
```apache
# VAPT Protection: {risk_id}
<IfModule mod_headers.c>
    Header always set {HEADER_NAME} '{HEADER_VALUE}'
</IfModule>
```

### PHP Functions — Action Hook
```php
// VAPT Protection: {risk_id} - {title}
add_action('{HOOK_NAME}', 'vapt_{CALLBACK_NAME}');
function vapt_{CALLBACK_NAME}() {
    // Implementation
}
```

### PHP Functions — Filter Hook
```php
// VAPT Protection: {risk_id} - {title}
add_filter('{HOOK_NAME}', 'vapt_{CALLBACK_NAME}');
function vapt_{CALLBACK_NAME}($arg) {
    // Implementation
    return $modified_arg;
}
```

### fail2ban — Jail Config
```ini
# VAPT Protection: {risk_id}
[{JAIL_NAME}]
enabled = true
port = http,https
filter = {FILTER_NAME}
logpath = /var/log/apache2/access.log
maxretry = {MAX_RETRY}
bantime = {BAN_TIME}
findtime = {FIND_TIME}
```

### Nginx — Server Tokens
```nginx
# VAPT Protection: {risk_id}
server_tokens off;
```
```apache
# Apache variant
ServerTokens Prod
ServerSignature Off
```
```apache
# .htaccess fallback
Header unset Server
Header unset X-Powered-By
```

---

## 8. COMMON AI ERROR PATTERNS TO AVOID

| Error Pattern | Prevention |
|---|---|
| Using "htaccess" instead of ".htaccess" | QER-001: always include the leading dot |
| add_constant used with PHP Functions | QER-002: add_constant is ONLY for wp-config.php |
| Leaving `{CONSTANT_NAME}` in code output | QER-003: always substitute from source step data |
| Forgetting vapt_ prefix | QER-004: check all PHP function names before emitting |
| Setting backup_required: false | QER-005: it is ALWAYS true |
| Missing rollback_steps | QER-007: always copy from protection.rollback_steps |
| Inventing API endpoints | Always use the derivation formula in Section 6 |
| Wrong CVSS score | QER-009: copy exactly from severity.cvss_score |
| Missing scan button | Always append scan action if not in ui_configuration.actions |
| fail2ban missing extra form fields | For RISK-007: add max_retry, ban_time, find_time fields |
| HSTS max-age < 31536000 | QER-003 enforcement: minimum value is 31536000 |
| WordPress Core using OP-PHP-002 | Use OP-WPC-FILTER-001 for WordPress Core filter hooks |

---

## 9. OUTPUT FILE STRUCTURE

```json
{
  "schema_info": { ... },
  "global_ui_config": { ... },
  "risk_interface_definitions": [
    { /* RISK-001 RiskInterfaceDefinition */ },
    { /* RISK-002 RiskInterfaceDefinition */ },
    ...
    { /* RISK-012 RiskInterfaceDefinition */ }
  ]
}
```

The `risk_interface_definitions` array MUST contain exactly 12 items,
ordered RISK-001 through RISK-012.

---

## 10. FINAL QUALITY SCORE CALCULATION

After generating all 12 risks, calculate your quality score:

```
Total checks = 12 risks × 10 rules = 120 checks
Quality Score = (Passing checks / 120) × 100%
Target = ≥ 90% = ≥ 108/120 passing checks
```

If score < 90%: identify which QERs are failing across which risks and fix.

CRITICAL failures (QER-001, QER-002, QER-003) each count as -5% regardless of
how many risks they affect, as they indicate a systematic generation failure.

---

## 11. REFERENCES

| File | Role |
|---|---|
| `VAPT-SixTee-Risk-Catalogue-12-EntReady_v3_4.json` | Source data — read only |
| `VAPT_Enforcer_Pattern_Library.json` | Pattern rules, code templates, QERs |
| `VAPT_Interface_Schema_Spec.json` | Output schema contract |
| `VAPT_Interface_Schema_Output.json` | Reference output (generated by this pipeline) |

---

*Generated by VAPT AI Agent Pipeline — Schema v3.4.0 — February 2026*

---

## 12. EXTENSION v2.0 — CLOUDFLARE, IIS & CADDY

### Overview

Every risk now carries an `alternative_enforcers` object alongside the original
`enforcement_config`. The AI Agent must populate **all three** alternative enforcer
configs for every risk when generating the Interface Schema.

```json
"alternative_enforcers": {
  "Cloudflare": { ... },
  "IIS":        { ... },
  "Caddy":      { ... }
}
```

The **original enforcer** (wp-config.php, .htaccess, PHP Functions, WordPress Core,
fail2ban, Nginx) remains the **primary**. Alternative enforcers are additive and
can be combined for layered defence (see SCENARIO-007 in Platform Decision Matrix).

---

### 12.1 Updated QER-001 — Valid Enforcer Names (now 9)
```
"wp-config.php" | ".htaccess" | "PHP Functions" | "WordPress Core" |
"fail2ban"      | "Nginx"     | "Cloudflare"    | "IIS"            | "Caddy"
```

### 12.2 Updated QER-002 — Enforcer-Operation Whitelist Extension
```
Cloudflare  → add_waf_rule, add_rate_limit_rule, add_transform_rule, enable_hsts
IIS         → add_request_filter, add_url_rewrite, add_dynamic_ip_restriction,
              modify_response_headers, add_security_header, add_custom_error
Caddy       → add_respond_rule, add_rate_limit_directive, add_header_directive,
              add_error_handler
```

---

### 12.3 Cloudflare Generation Rules

**Expression Syntax:**
| Target | Syntax |
|--------|--------|
| Exact path | `http.request.uri.path eq "/xmlrpc.php"` |
| Path contains | `http.request.uri.path contains "/wp-json/"` |
| Path glob | `http.request.uri.path wildcard "/wp-json/*"` |
| Query string | `http.request.uri.query contains "author="` |
| Request method | `http.request.method eq "POST"` |
| Header exists | `http.request.headers["authorization"] matches "Bearer .+"` |
| IP range | `ip.src in {192.0.2.0/24}` |

**Operation selection per risk:**
| Risks | CF Operation | CF Op ID |
|-------|-------------|---------|
| RISK-001,002,003,005,006,011 | add_waf_rule | OP-CF-001 |
| RISK-004,007,009 | add_rate_limit_rule | OP-CF-002 |
| RISK-008,010 | add_transform_rule | OP-CF-003 |
| RISK-012 | enable_hsts | OP-CF-004 |

**Critical notes:**
- RISK-001 CF rule is **secondary** (wp-config.php is primary) — note in implementation
- RISK-006 uses `managed_challenge` NOT `block` — preserves Gutenberg editor functionality
- RISK-008 CF is **supplementary only** — CF cannot modify response body, PHP Functions is primary
- RISK-010 CF is **preferred** — CF proxy already hides Server header, Transform Rule removes X-Powered-By
- RISK-012 CF is **preferred** — native HSTS toggle, no rules needed
- Rate limit rules: `period` in seconds, `requests_per_period` is the threshold, `mitigation_timeout` is ban duration
- HSTS: `max_age` minimum 31536000; `preload: true` REQUIRES `include_subdomains: true`

---

### 12.4 IIS Generation Rules

**Web.config XML structure:**
```xml
<configuration>
  <system.webServer>
    <!-- INSERT RULES HERE -->
  </system.webServer>
</configuration>
```

**Operation selection per risk:**
| Risks | IIS Operation | IIS Op ID |
|-------|--------------|---------|
| RISK-001,002,011 | add_request_filter | OP-IIS-001 |
| RISK-003,005,006 | add_url_rewrite | OP-IIS-002 |
| RISK-004,007,009 | add_dynamic_ip_restriction | OP-IIS-003 |
| RISK-010 | modify_response_headers | OP-IIS-004 |
| RISK-012 | add_security_header | OP-IIS-005 |
| RISK-008 | add_custom_error | OP-IIS-006 |

**Critical notes:**
- `add_request_filter` (hiddenSegments) returns **404** not 403 — this is correct IIS behaviour
- `add_url_rewrite` requires **URL Rewrite Module 2.0** — flag as prerequisite
- `add_dynamic_ip_restriction` requires **Dynamic IP Restrictions Extension**
- Rule names MUST start with `VAPT {risk_id}:` for traceability
- `{QUERY_STRING}` in URL Rewrite conditions is an **IIS server variable** (NOT a placeholder to substitute)
- Always use `stopProcessing="true"` on rewrite rules
- For RISK-007/009: scope Dynamic IP Restriction using `<location path="wp-login.php">` wrapper
- RISK-010: Server header removal requires BOTH web.config AND registry key — document registry step as manual_step
- `backup_required: true` for ALL IIS operations (web.config backup before modification)

---

### 12.5 Caddy Generation Rules

**Caddyfile v2 structure:**
```caddy
your-domain.com {
    # Named matchers MUST be defined before use
    @matcher_name {
        path /target-path
    }
    respond @matcher_name "Forbidden" 403

    # Header directives
    header {
        -X-Powered-By
        defer
    }
}
```

**Operation selection per risk:**
| Risks | Caddy Operation | Caddy Op ID |
|-------|----------------|-----------|
| RISK-001,002,003,005,006,011 | add_respond_rule | OP-CADDY-001 |
| RISK-004,007,009 | add_rate_limit_directive | OP-CADDY-002 |
| RISK-010,012 | add_header_directive | OP-CADDY-003 |
| RISK-008 | add_error_handler | OP-CADDY-004 |

**Critical notes:**
- Named matchers `@name` MUST be defined before the directive that uses them
- Path glob: `https://{{SITE_URL}}/wp-json/*` matches all subpaths (unlike .htaccess `^pattern`)
- Query matcher: `query author=*` (glob value, not regex)
- NOT in matcher: `not header Authorization "Bearer *"` — uses glob
- `add_rate_limit_directive` REQUIRES xcaddy custom build — always flag this as a prerequisite
- `defer` keyword in `header` blocks: ensures headers added by upstream PHP-FPM are also modified
- Rate limit returns **429** (Too Many Requests) — not 403. This is RFC-correct.
- `backup_required: true` + `reload_required: true` for ALL Caddy operations
- Reload command: `systemctl reload caddy` — must be included in implementation notes
- RISK-008 Caddy is **supplementary** — handle_errors cannot override WordPress body content

---

### 12.6 Priority Classification

When generating `alternative_enforcers`, set the `priority` field:

| Priority | Meaning |
|----------|---------|
| `preferred` | Best implementation for this risk on this platform (e.g., CF native HSTS, CF edge rate limiting) |
| `equivalent` | Full functional parity with primary enforcer |
| `supplementary` | Partial protection — primary enforcer still required (e.g., RISK-008 on CF/Caddy/IIS) |
| `secondary` | Complements primary, does not replace it (e.g., RISK-001 CF adds edge blocking on top of wp-config) |

---

### 12.7 Enforcement Selection UI Component

Each risk's `enforcement_selection` object drives a multi-select radio group in the UI:
```json
{
  "component_type": "radio_group",
  "options": [
    {"value": "primary", "label": "Primary (enforcer_type)", "default": true},
    {"value": "Cloudflare", "label": "Cloudflare", "requires": "..."},
    {"value": "IIS", "label": "IIS", "requires": "..."},
    {"value": "Caddy", "label": "Caddy", "requires": "..."}
  ],
  "multi_select": true,
  "help_text": "Multiple enforcers can be enabled for layered defence"
}
```
`multi_select: true` — users can activate multiple platforms simultaneously.

---

### 12.8 Deployment Scenario Decision Tree

```
Q: Is site DNS-proxied through Cloudflare?
  YES → Enable Cloudflare enforcer (preferred where priority="preferred")
  NO  → Skip Cloudflare

Q: What is the web server?
  Apache/cPanel  → Use .htaccess (original primary)
  IIS/Windows    → Use IIS web.config
  Caddy          → Use Caddyfile (note rate_limit plugin requirement)
  Nginx          → Use Nginx conf (nginx equivalents extend .htaccess patterns)

Q: Is SSH/server access available?
  YES → Enable fail2ban for RISK-007 (most robust rate limiting)
  NO  → Use PHP transients (RISK-007) or Cloudflare Rate Limiting

Q: Maximum security desired?
  → Enable ALL available enforcers simultaneously (layered defence)
  → Cloudflare blocks at edge, web server blocks at origin
```

---

*Extension v2.0.0 — Cloudflare / IIS / Caddy — February 2026*
